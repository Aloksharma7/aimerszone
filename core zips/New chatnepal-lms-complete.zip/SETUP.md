# Running the LMS locally

Two applications, three terminals. Follow in order — the frontend cannot start
usefully until the backend is migrated and running.

## What you need first

| Tool | Version | Check with |
|---|---|---|
| PHP | 8.2 or newer | `php -v` |
| Composer | 2.x | `composer -V` |
| MySQL or MariaDB | 8.0 / 10.6+ | `mysql --version` |
| Node.js | 20 or newer | `node -v` |

PHP needs these extensions: `pdo_mysql`, `mbstring`, `openssl`, `fileinfo`,
`bcmath`, `curl`, `zip`. On most installs they are already on. Check with
`php -m`.

---

## Part 1 — Backend

### 1.1 Extract and install

```bash
unzip nepal-lms-api.zip
cd nepal-lms-api
composer install
```

`composer install` pulls Laravel and its dependencies. First run takes a few
minutes.

### 1.2 Create the database

```bash
mysql -u root -p
```

```sql
CREATE DATABASE nepal_lms CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
EXIT;
```

### 1.3 Configure

```bash
cp .env.example .env
php artisan key:generate
```

Open `.env` and set your database password:

```env
DB_DATABASE=nepal_lms
DB_USERNAME=root
DB_PASSWORD=your_mysql_password
```

Leave everything else as it is for local work. The defaults already point at
`localhost:3000` for the frontend.

### 1.4 Create the schema

```bash
php artisan migrate --seed
```

This creates ~42 tables, the roles and permissions, default settings, the three
payment methods, and the first administrator.

**Watch the output.** It prints the administrator email and password **once**:

```
Administrator created.
  email:    admin@example.com
  password: <a random string>
  This password must be changed at first sign-in.
```

Copy that password now. It is not recoverable.

To choose your own instead, set these in `.env` *before* migrating:

```env
ADMIN_EMAIL=you@yourdomain.com
ADMIN_PASSWORD=YourChosenPass123
```

### 1.5 Sample content (recommended)

```bash
php artisan db:seed --class=Database\\Seeders\\DemoContentSeeder
```

Gives you a course, a batch with a teacher, past and upcoming classes,
recordings, FAQs, and five accounts — all with password `Demo12345`:

| Account | Role |
|---|---|
| `teacher@example.test` | Teacher with an assigned batch |
| `officer@example.test` | Enrollment officer |
| `accountant@example.test` | Accountant, with a payment waiting to review |
| `student@example.test` | Student with an active enrollment |
| `applicant@example.test` | Student whose payment is under review |

Without this, every screen is empty and it is hard to tell "working" from
"broken".

### 1.6 Storage link

```bash
php artisan storage:link
```

### 1.7 Start it — terminal 1

```bash
php artisan serve
```

Leave this running. It serves `http://127.0.0.1:8000`.

Check it: open `http://127.0.0.1:8000/api/v1/public/settings` in a browser. You
should see JSON with your institution name.

### 1.8 Queue worker — terminal 2

```bash
php artisan queue:work
```

**This is not optional.** Password reset emails, batch progress recalculation
and Zoom meeting provisioning are all queued. Without a worker they never run,
with no visible error.

---

## Part 2 — Frontend

### 2.1 Extract and install — terminal 3

```bash
unzip nepal-lms-frontend.zip
cd nepal-lms-frontend
npm install
```

### 2.2 Configure

Create a file called `.env.local` in the frontend folder:

```env
NEXT_PUBLIC_USE_MOCK_DATA="false"
ALLOW_MOCK_DATA_IN_PRODUCTION="false"
API_INTERNAL_URL="http://127.0.0.1:8000"
NEXT_PUBLIC_API_BASE_URL=""
SESSION_COOKIE_NAME="lms_session"
NEXT_PUBLIC_ALLOWED_EXTERNAL_HOSTS="www.youtube-nocookie.com"
```

Three of these matter more than they look:

- **`NEXT_PUBLIC_API_BASE_URL` must stay empty.** That keeps browser calls
  same-origin through the rewrites in `next.config.ts`, which is what makes
  Sanctum's cookie authentication work. Pointing it at the Laravel URL causes
  cross-site cookie failures that look like random logouts.
- **`SESSION_COOKIE_NAME` must equal `SESSION_COOKIE` in the Laravel `.env`**
  (both are `lms_session`). A mismatch produces an endless redirect to `/login`.
- **`NEXT_PUBLIC_USE_MOCK_DATA="false"`** switches off the preview data so you
  are exercising the real API.

### 2.3 Type check before running

```bash
npm run check
```

This has never been run in my environment, so expect it to find something. Fix
or send me the output before moving on.

### 2.4 Start it

```bash
npm run dev
```

Open `http://localhost:3000`.

---

## Part 3 — First walkthrough

Do these in order. Each one proves a layer works.

1. **`http://localhost:3000`** — the public site renders, institution name from
   the API.
2. **`/courses`** — the demo course appears. *(Proves the public API path.)*
3. **`/login`** — sign in as `admin@example.com` with the printed password. You
   should be redirected to change your password. *(Proves auth, cookies, CSRF.)*
4. **`/admin/settings`** — change the institution name, save, then reload the
   public site. The header should show the new name. *(Proves admin-controlled
   config end to end.)*
5. **`/admin/platform`** — the feature switches. Leave them off for now.
6. **`/admin/categories`** — create a category. *(Proves a write path.)*
7. Sign out. Sign in as `accountant@example.test` / `Demo12345`.
8. **`/accounting/payments`** — the pending payment is there. Open it, approve
   it. *(This is the critical one: it should create an enrollment and a
   receipt.)*
9. Sign out. Sign in as `student@example.test` / `Demo12345`.
10. **`/student/dashboard`** — the course appears with classes and recordings.

If step 8 produces an active enrollment and a receipt, the core money-to-access
path works.

---

## When something breaks

**`SQLSTATE[HY000] [1045] Access denied`**
Wrong `DB_PASSWORD` in the backend `.env`.

**`could not find driver`**
`pdo_mysql` is not enabled. Enable it in `php.ini` and restart.

**Endless redirect to `/login` after signing in**
`SESSION_COOKIE_NAME` (frontend) and `SESSION_COOKIE` (backend) do not match.

**`419` errors on every form**
Use `localhost` for the frontend and `127.0.0.1` for the API exactly as written,
or make both `localhost`. Mixing them makes two different cookie origins.

**`Class "DB" not found` or similar**
`composer install` did not finish. Run it again and read the output.

**Frontend loads but every page shows "The page could not be loaded"**
The backend is not running, or `API_INTERNAL_URL` is wrong. Check terminal 1 —
the actual error is printed there, not in the browser.

**Password reset emails never arrive**
Expected locally: `MAIL_MAILER=log` writes them to
`storage/logs/laravel.log` instead of sending. Open that file and copy the link.

---

## Important caveat

None of this code has ever been executed — no `composer install`, no `migrate`,
no `npm run check`. It has been reviewed statically several times and real bugs
were found and fixed each time, but the first run is where genuine typos
surface.

Expect to hit something. Send me the exact error text and which step it was on,
and I will fix it.
