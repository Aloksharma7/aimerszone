# Nepal LMS — handoff brief

Paste this whole file into the new chat, and upload `nepal-lms-api.zip` and
`nepal-lms-frontend.zip` alongside it.

---

## What this is

A learning management system for a Nepal-based coaching institute. Two
applications:

- **Frontend** — Next.js 16 App Router, React 19, Tailwind 4, TypeScript strict,
  TanStack Query, axios. Pre-existing; I have modified it.
- **Backend** — Laravel 12 API on MySQL, built from scratch to match the
  frontend's OpenAPI contract.

Auth is **Sanctum stateful cookies** — no bearer tokens in the browser. The
frontend proxies `/api/*` same-origin through `next.config.ts` rewrites, which
is what makes the cookie work.

## Decisions already made — do not relitigate these

| Decision | Choice |
|---|---|
| Database | MySQL / MariaDB |
| Integrations | Real Zoom Server-to-Server OAuth + YouTube Data API v3 |
| Mock data | Keep the code, switch the env flag off. **Do not delete mock files.** |
| Config | Everything the admin might change lives in the `settings` table, not `.env` |
| Scope | Free platform. No paid services except Zoom premium. |
| Mobile | Planned separately. Web keeps the full feature set with admin on/off toggles. |

## The intended flow

Student buys → uploads payment screenshot → staff or admin verifies → student
activated in the batch → attends Zoom live classes → recordings go to YouTube
unlisted and are viewable only inside the LMS → PDFs and notes available →
teacher schedules one-off or recurring classes from the LMS → students notified
→ attendance recorded.

---

## Architecture worth knowing before changing anything

### Backend

```
app/
  Enums/         status vocabularies shared with the frontend DTOs
  Http/
    Controllers/Api/V1/{Auth,Account,PublicSite,Student,Teacher,Staff,Accounting,Admin}
    Middleware/  request id, response meta, role, permission, idempotency, maintenance, security headers
    Resources/   DTO shaping — field names match src/lib/data/api-dtos.ts exactly
  Models/        ~38 models, ULID primary keys
  Policies/      per-record authorization
  Services/      SettingsRepository, FeatureGate, AuditLogger, AccessGuard, DeviceGuard,
                 WatermarkService, MediaLinkService, AttemptGrader, PaymentDecisionService,
                 EnrollmentProgressService, NotificationDispatcher, UserDirectory
  Services/Integrations/  ZoomClient, YouTubeClient, SmsClient, EsewaClient, ClassMeetingService
  Jobs/          RecalculateBatchProgress, ProvisionClassMeetings
  Support/       ApiResponse envelope, exception → machine-code mapping, CsvStream
```

**Response envelope** is built in one place (`App\Support\ApiResponse`).
`meta.request_id` and `meta.generated_at` are appended by middleware.

**Authorization has four layers**, and the outer ones are never treated as
sufficient: `auth` → `account.usable` → `role:` → `permission:` → **policies**.
`AccessGuard` is the single answer to "may this user reach this batch's
content".

**Administrators bypass every role gate** (`EnsureRole` and `Gate::before`), so
an admin can use the teacher and staff screens.

### Load-bearing invariants — breaking these is a real bug

1. **`PaymentDecisionService::approve()` is the only path by which money becomes
   access.** One transaction, row-locked: approve the payment, activate the
   enrollment, issue a receipt with an immutable snapshot, write the audit
   entry. All four or none.
2. **Separation of duties.** Whoever submitted payment evidence cannot approve
   it; whoever requested a refund cannot record the payout; whoever raised an
   enrollment exception cannot grant it. Re-checked *inside* the lock, not just
   in the policy.
3. **Media is never a permanent URL.** Live joins, recordings, downloads and
   payment evidence return `{url, expires_at}` from a signed route that
   **re-runs the policy when opened**.
4. **Correct answers never reach a student payload.** Only the teacher builder
   endpoint serialises `is_correct`.
5. **Test timing is server-authoritative.** `started_at` / `expires_at` are
   stored at creation; a scheduled command closes overdue attempts.
6. **Corrections never edit an approved payment.** Adjustments and refunds are
   new signed ledger rows — the money trail is append-only.
7. **A provider outage never blocks teaching.** If Zoom fails, the class is
   still created and marked for manual fallback.
8. **`FeatureGate` separates "switched on" from "able to run".** A feature
   enabled without credentials reports `ready: false` with what is missing.

### Frontend

- Portal layouts wrap children in `ProtectedPortalLayout` → `requirePortalAccess`
- `proxy.ts` gates the five portal prefixes on session-cookie presence
- `hasRole()` returns true for admin — this must match the backend
- `browserRequest()` handles CSRF priming, 419 retry-once, idempotency keys, and
  sends `X-Device-Id`
- `siteConfig` is kept as a **fallback** for `/public/settings`, deliberately not
  deleted: an API blip should not take the marketing site down

---

## State of play

Everything in the intended flow is built, on both sides. Then:

- I reviewed it statically four times. Each pass found real bugs. One pass found
  a bug I had introduced in the previous pass.
- The user then ran it for the first time and found seven more — all fixed.

**Nothing has ever been executed in my environment.** No `composer install`, no
`migrate`, no `npm run check`. There is no PHP and no network in my sandbox.
Everything is verified by static analysis: reference resolution, route/signature
matching, mass-assignment audit, brace and JSX balance, frontend↔backend path
cross-check.

**Treat that as the main risk.** Reading has hit diminishing returns; the next
bugs are behind `npm run dev`.

### Required after deploying the latest zip

```bash
php artisan migrate    # backfills student permissions
```

---

## Known gaps, carried forward

| Gap | Notes |
|---|---|
| Receipt PDFs | Record and snapshot exist, download route wired, no PDF generated. Close this before promising receipts. |
| `topic_performance` | Returns empty until questions carry topic tags. |
| Zoom attendance import | Needs `report:read:admin` and a paid plan. Returns an explanatory empty result otherwise. |
| APM / error tracking | Not configured. |
| Backup verification | Not automated. |
| **Unlisted YouTube is not private** | Anyone with the link can watch, forever. Options given: accept it with watermarking, self-host with signed URLs, or pay for Vimeo/Bunny. **The user has not decided.** |
| No Android app | Every Nepali competitor is mobile-first. Planned separately. |
| No offline downloads | Needs the mobile app. |

---

## Operational notes that bite

- **The queue worker is not optional.** Password reset emails, batch progress
  recalculation and Zoom meeting provisioning are all queued. Without
  `php artisan queue:work` they silently never run.
- **Back up `storage/app/private` with the database.** Payment evidence lives on
  disk, not in the database. A restore without it leaves approved payments with
  no supporting document.
- **`NEXT_PUBLIC_API_BASE_URL` must stay empty** — filling it in breaks Sanctum
  cookies and looks like random logouts.
- **`SESSION_COOKIE_NAME` (frontend) must equal `SESSION_COOKIE` (backend)** or
  you get an endless redirect to `/login`.

See `SETUP.md` for the full run process and `PRODUCTION.md` before going live.

---

## How to work with this codebase

Things I would want a fresh reviewer to know:

- **Permission strings are a recurring failure mode.** Three separate bugs came
  from the frontend gating a nav item on a permission string that either did not
  exist in the backend catalogue or was not granted to that role. The item then
  disappears silently with no error anywhere. When touching navigation, check
  `config/lms.php` for both the catalogue **and** the role composition.
- **Route ordering matters.** Literal segments must be registered before
  wildcards, or `/users/export` gets captured by `/users/{user}`. This has bitten
  three times.
- **Public pages must not assume a guest.** A signed-in student reaching a
  `/register` link is bounced by the guest guard with no explanation. This caused
  the purchase dead-end.
- **Say what the code actually does.** Two bugs were interfaces claiming
  something untrue — an autosave that said "retrying" and did not, and an offline
  banner that promised local storage that did not exist. Both were caught by
  reading the copy against the implementation.

---

## Suggested first message in the new chat

> I'm continuing work on my Nepal LMS. Attached are the Laravel API and Next.js
> frontend, plus a handoff brief with all the context and decisions. Read the
> brief first.
>
> Nothing has been run yet in your environment, so don't assume it works.
> [Then say what you want next — see below.]

### Likely next steps, roughly in value order

1. **Run it and report errors.** `composer install`, `migrate --seed`,
   `npm run check`, then walk a student from payment to watching a recording.
   This is worth more than any further feature.
2. **Decide the video question.** Self-host with signed URLs, or accept unlisted
   YouTube with watermarking. It changes how recordings are built.
3. **Receipt PDFs**, if receipts are being promised to students.
4. **Support ticket management** — students can submit; nobody can reply yet.
5. **Certificates on completion.**
6. **Android app** — the biggest market gap, and a separate project.
