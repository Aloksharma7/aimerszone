# Frontend — features and integrations batch

Everything the backend gained is now reachable from the interface.

## New: `/admin/platform`

The control surface you asked for. Six switches, and — the important part — each
one reports **enabled** and **ready** separately. Turn SMS on before pasting a
token and the panel says so, naming exactly what is missing, instead of looking
like it works and failing at the worst moment.

**Secrets are write-only.** The API never returns a stored token, so the fields
start empty and a blank submission means "leave it alone". Editing your sender
ID cannot silently wipe the token.

| Section | What it does |
|---|---|
| Features | single-device login, watermark, SMS, eSewa, support tickets, free courses |
| SMS provider | Sparrow or generic, endpoint, sender ID, token, per-event switches |
| eSewa | sandbox/live, merchant code, secret key, live-mode warning |
| Watermark | opacity and movement interval, with live preview of the numbers |

## Single-device login

`src/lib/api/device-id.ts` generates a stable id per browser install, sent as
`X-Device-Id` on every request.

**localStorage rather than a cookie**, deliberately: it must survive the session
cookie being cleared at sign-out. A cookie would make every sign-in look like a
new device and lock students out of their own accounts.

It is not a security token and is not treated as one — it identifies a device so
an account can be held to one, while the session is still authenticated
independently.

## Watermark overlay

`VideoWatermark` draws the viewer's name and part-mobile across the player,
moving on a timer so one cropped screenshot does not yield a clean frame.
`pointer-events-none` keeps the player controls usable underneath.

The payload is issued per playback request, so it cannot be fetched once, cached
and stripped from later views.

Being straight: this is deterrence, not DRM. Someone can still film the screen —
what changes is that the copy names the account it came from.

## Features that were dead, now usable

**Notes and resources** — `/teacher/batches/[batchId]/resources`. Upload, stage,
release, withdraw, delete, with download counts. Release is separate from upload
so a teacher can prepare a module and publish it when the class reaches it.

**Syllabus builder** — `/admin/courses/[courseId]/syllabus`. Modules and lessons
with reordering. Existing ids are sent back on save, which is what lets the API
keep lesson rows across a reorder — and with them, every student's completion
record.

**Recurring classes** — `/teacher/classes/recurring`. Daily or weekly, with a
day picker and a live estimate of how many classes will be created.

**eSewa checkout** — a real form POST, because eSewa will not accept a JSON body
or a cross-origin fetch. Success and failure pages included; the success page
hands the signed payload straight to the API and interprets nothing itself,
since only the server holds the secret that proves a payment is real.

**Free enrollment** — `FreeEnrollButton`. Joining a free course was previously
impossible.

## Files

```
NEW  src/lib/api/device-id.ts
NEW  src/components/admin/platform-controls.tsx
NEW  src/components/admin/syllabus-builder.tsx
NEW  src/components/teacher/resource-manager.tsx
NEW  src/components/teacher/recurring-class-form.tsx
NEW  src/components/student/video-watermark.tsx
NEW  src/components/student/enrollment-actions.tsx
NEW  src/components/student/esewa-callback.tsx
NEW  src/app/admin/platform/page.tsx
NEW  src/app/admin/courses/[courseId]/syllabus/page.tsx
NEW  src/app/teacher/classes/recurring/page.tsx
NEW  src/app/teacher/batches/[batchId]/resources/page.tsx
NEW  src/app/student/payments/esewa/{success,failure}/page.tsx

EDIT src/lib/api/browser-client.ts          sends X-Device-Id
EDIT src/lib/data/admin.ts                  feature/SMS/eSewa types, syllabus fetcher
EDIT src/lib/data/teacher.ts                batch resources fetcher
EDIT src/components/student/secure-learning-actions.tsx   watermark on the player
EDIT src/components/portal-shell.tsx        Platform nav entry
```

## Verified

All 22 touched files: imports resolve, exports present, braces balanced. Every
frontend API path cross-checked against the backend route table — no orphans.

## Still not wired

Small gaps, none blocking: class cancel button, admin device-reset screen,
refund completion UI, enrollment-request approval screen, notification
mark-read, student receipts list.

## Caveat

No `node_modules` and no network in my environment, so **`tsc`, `next build` and
the linter did not run.** Structure was verified by hand. Run `npm run check`
before trusting this.
