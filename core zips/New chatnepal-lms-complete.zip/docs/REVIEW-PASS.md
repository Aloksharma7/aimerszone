# Review pass — self-review and closing gaps

## Three issues found, one of them mine

### 1. My offline message was a lie

I wrote *"your work is held on this device"* into the test runner banner while
nothing was persisted — answers lived in React state only. A tab crash or an
accidental close on a low-memory phone mid-exam lost everything, after the
student had been told it was safe.

That is the same class of bug I had just criticised the original autosave for:
telling the user something reassuring that the code does not do.

*Fixed:* `src/lib/data/attempt-draft.ts` writes every change to localStorage
synchronously. On starting an attempt the runner merges the server's answers
with anything this device saved but never managed to send, and marks the result
dirty so it is re-sent without the student touching anything.

Three details that matter:
- The draft is a **backup, never the source of truth**. Grading uses only what
  the server received; a restored draft is re-sent for the server to accept.
- Restored answers are filtered against the questions actually in the attempt,
  so a stale draft cannot inject anything.
- Drafts from other attempts are pruned on start. Institution machines are often
  shared, and an exam draft is not something to leave in another student's
  browser.

### 2. Recurring classes would time out

`storeRecurring` created up to ~130 sessions and then looped through them
calling Zoom **synchronously**, with retries. At roughly half a second per call
that runs well past PHP's execution limit: the teacher got a gateway timeout
with no idea whether the term had been created.

*Fixed:* sessions are saved first and provisioning moves to
`ProvisionClassMeetings`. A class without a meeting yet is not broken — it shows
as pending sync, the scheduled command picks it up, and a manual fallback link
can be published at any time.

### 3. Auto-submit while offline stranded the student

Timer expires, network gone, flush fails, submit fails, raw error. The attempt
was not actually lost — the scheduled `lms:finalize-attempts` command closes and
grades expired attempts server-side — but the student had no way to know that.

*Fixed:* an automatic submit that fails now closes the attempt locally and says
so plainly, rather than showing an error to someone who has just finished an
exam.

## Six gaps closed

| Gap | Where |
|---|---|
| Class cancel | `CancelClassButton` |
| Device reset | `ResetDevicesButton`, with the device list |
| Refund completion | `CompleteRefundButton` |
| Enrollment request approval | `EnrollmentRequestDecision` |
| Notification mark-read | `MarkReadButton` |
| Student receipts list | `/student/receipts` |

The four audited actions share one `ReasonAction` prompt that requires a written
reason before it will proceed. Each of these is something an auditor may later
ask about — a cancelled class, a released device, money paid out — so the reason
is collected while the person still remembers it, and stored with the audit
entry.

## Verified this pass

Backend: 246 files, all references resolve, balanced. Frontend: imports resolve,
React hooks imported where used, braces balanced, and every API path
cross-checked against the route table — no orphans.

## Caveat, unchanged

No `node_modules` and no network here, so `tsc`, `next build`, `php artisan test`
and the linters have still never run. Everything above was verified by reading
and by static checks.
