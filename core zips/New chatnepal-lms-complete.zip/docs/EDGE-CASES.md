# Edge case audit — findings and fixes

## Critical: silent data loss in the test runner

Three bugs that combined into the worst possible failure — a student loses work
they were explicitly told was safe.

**1. The autosave claimed to retry and did not.** The interface rendered
`"Save failed — retrying"` while the code did nothing of the sort: the save
effect only re-fired when `answers` or `flagged` changed. A student who answered
the last question, hit a one-second network blip, and then touched nothing else
would lose that answer entirely — having been reassured it was being retried.

*Fixed:* the save is now a callable `flushAnswers()` with a real 5-second retry
loop that runs until the write lands or the attempt ends. The label matches
reality: `"Save failed — retrying every 5s"`.

**2. Auto-submit did not flush pending answers.** When the timer hit zero,
submit fired immediately. Anything still inside the 650 ms debounce window, or
any previously failed save, never reached the server — and the server graded
work the student had genuinely done.

*Fixed:* submit flushes first. On a **manual** submit a flush failure stops the
process with an explanation, because losing work silently is worse than making
the student wait. On an **automatic** submit the clock has expired and the
attempt must close, so it proceeds with whatever did land — the alternative is
an attempt that never closes.

**3. No offline detection.** "Saved" sat there looking healthy while nothing was
reaching the server.

*Fixed:* `online`/`offline` listeners, a `role="status" aria-live="polite"`
banner, and an immediate flush on reconnect — reconnecting is the best moment to
push what is outstanding.

## Uploads on a slow connection

The axios client had a flat 30-second timeout. Correct for a JSON call, wrong
for a 20 MB PDF on Nepali mobile data: the request aborted mid-transfer and
surfaced as a generic failure the user could not act on.

*Fixed:* requests carrying `FormData` get 180 seconds. FormData is the reliable
signal that bytes are actually moving.

## Keyboard

Your original test runner is properly accessible and I left it alone — real
`<input type="radio">` inside `<label>`, wrapped in `<fieldset>` with an
`sr-only` `<legend>`. Arrow keys move between options, space selects, screen
readers announce the group. That is correct work.

**The six components I added were not.** None used `<form>`, so pressing Enter
did nothing — inconsistent with every existing form in the app and slow for
anyone not using a mouse.

*Fixed:* category manager, create user, resource upload and recurring classes
are now real `<form>` elements with `type="submit"` buttons. Icon-only delete
buttons got `aria-label` so they are not announced as just "button".

## Checked and already correct

- **Clock skew** — `attemptRemaining()` computes a server offset from
  `serverNow` rather than trusting the device clock. A student with a wrong
  system time still gets the right countdown.
- **Refresh mid-test** — the API resumes the existing attempt rather than
  consuming a second one.
- **Tab close mid-test** — `beforeunload` guard already present.
- **Double submit** — idempotency keys on every sensitive mutation server-side.
- **Session expiry mid-action** — 419 re-primes the CSRF cookie and retries once.
- **eSewa double callback** — a `started` ref guards React's double-invoked
  effects in development, and the server treats a repeat arrival as success
  rather than an error.
- **Destructive actions** — `window.confirm`, which is keyboard accessible and
  screen-reader friendly by default.

## Still open

Small UI gaps, none of which lose data: class cancel button, admin device-reset
screen, refund completion, enrollment-request approval, notification mark-read,
student receipts list.

## Caveat

Still no `node_modules` and no network here, so `tsc`, `next build` and the
linter have not run. Imports, hook imports, JSX tag pairing and brace balance
were all verified by hand across every touched file.
