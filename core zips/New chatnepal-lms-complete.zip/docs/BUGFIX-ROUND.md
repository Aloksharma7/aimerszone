# Bug fixes from your first real run

Every one of these needed the app running to find. Static analysis could not
have caught most of them.

## After deploying: run one migration

```bash
php artisan migrate
```

Student permissions are backfilled by a migration, because the role seeder only
fills empty roles and yours already has rows.

---

## 1. Explore and Payments were missing from the student menu

**Cause:** a permission mismatch, not a missing page. The student role granted
only `recordings.view, resources.view, tests.view, announcements.view`. The
navigation gated Explore on `courses.view` — which students did not have — and
Payments on `payments.view-own`, **which does not exist in the backend catalogue
at all**. Both items were therefore hidden with no error anywhere.

That is why you had to leave the portal for the public site just to find a
course.

**Fixed:** students now hold `courses.view`, `batches.view`, `payments.view`,
`receipts.view` and `support.view`. Their queries were always scoped to their
own records, so this grants navigation, not new data. The nav now points at
permissions that exist. Staff's "Account Assistance" was hidden the same way and
is also fixed.

## 2. Buying a course dead-ended on the dashboard

**Cause, and this one was mine.** The public batch page's button was
`href="/register"` — written for a logged-out visitor. When I added the guest
guard last round, `/register` began redirecting signed-in users to their portal.
So: choose batch, agree, continue, land on the dashboard, no explanation.

The guard was right; the page's assumption that every visitor is a guest was
wrong.

**Fixed:** both public course and batch pages now check for a session. A
signed-in student goes to the payment wizard for that exact batch (or straight
to activation if the course is free); guests still register first, and their
`returnTo` brings them back to the batch afterwards.

## 3. Signing in as admin landed on a student URL

**Cause:** `returnTo` was honoured without checking who was signing in. Being
bounced to `/login?returnTo=/student/dashboard`, then signing in as an
administrator, sent the administrator into the student portal.

**Fixed:** a `returnTo` pointing at a portal is honoured only when the account
signing in can actually open it. Otherwise they land on their own portal.

## 4. Back button showed the previous session

**Cause:** `Cache-Control: no-store` is already set on protected routes and
Chrome honours it, but Safari and Firefox still restore a fully rendered page
from the back-forward cache. On a shared institution computer that means the
next person can press Back and read the previous student's dashboard.

**Fixed:** a `pageshow` listener detects a bfcache restore (`event.persisted`)
and forces a reload, which re-runs the server component, finds no session, and
redirects to login. Normal navigation is untouched.

## 5. The search box did nothing

It was a `<div>` with a decorative `⌘K` badge — no input, no handler. It looked
functional, which is worse than not having it.

**Fixed:** a real search form per portal, pointing at the list that role
actually looks things up in, using the `?q=` filter those pages already support.
Students search courses, teachers their batches, staff students, accounting
payments, admin users.

There is no cross-entity search index, and pretending otherwise is what produced
the original placeholder.

## 6. Notifications navigated away instead of previewing

**Fixed:** the bell is now a dropdown — recent items in place, unread count on
the badge, "See all" through to the full page. Closes on outside click and
Escape. The list loads on first open rather than on every page load, since most
sessions never open it.

## 7. Admin could not upload PDFs, take attendance, or run classes

**Cause:** the backend already allows this — `EnsureRole` lets an administrator
through every role gate, and `hasRole` was fixed last round. The **navigation**
simply never offered those screens, so an admin needed a second account to do
anything operational.

**Fixed:** the admin menu now includes Classes, Attendance, Content & PDFs,
Students and the Payments desk, pointing at the existing teacher and staff
screens. Those layouts already admit an administrator.

---

## Verified

Backend references resolve, balanced. Frontend imports resolve, balanced, every
nav href and search target maps to a real page.

`tsc` and `next build` still have not run here. Run `npm run check` first.
