# Nepal LMS — complete package

Everything needed to continue this project in a fresh conversation.

## Start here

1. **`HANDOFF.md`** — paste this into the new chat. All context, decisions,
   architecture, invariants, known gaps.
2. **`SETUP.md`** — how to run both applications locally, step by step.

## The code

| File | What |
|---|---|
| `nepal-lms-api.zip` | Laravel 12 API — ~247 PHP files, 49 tests |
| `nepal-lms-frontend.zip` | Next.js 16 frontend — modified from the original |

Neither contains `vendor/` or `node_modules/`. Run `composer install` and
`npm install` after extracting.

## Reference docs

In `docs/`, roughly in the order they were written:

| File | Covers |
|---|---|
| `BACKEND-README.md` | Architecture, security decisions, build status |
| `PRODUCTION.md` | Deployment, env changes, backups, first-install checklist |
| `VERIFICATION.md` | How to verify a build; findings from static review passes |
| `FRONTEND-CHANGES.md` | What changed in the frontend and why |
| `EDGE-CASES.md` | Offline, keyboard, upload and timing edge cases |
| `REVIEW-PASS.md` | Self-review findings, including a bug I had introduced |
| `BUGFIX-ROUND.md` | Bugs found in the first real run, with root causes |
| `FRONTEND-GUEST-GUARD.md` | Superseded — the fix described here is already applied |

## The one thing to keep in mind

**None of this has ever been executed.** There is no PHP and no network in the
environment it was written in. It has been reviewed statically several times and
real bugs were found and fixed each time — including bugs introduced by earlier
fixes — but the first genuine run is still ahead.

Run it before trusting it.
