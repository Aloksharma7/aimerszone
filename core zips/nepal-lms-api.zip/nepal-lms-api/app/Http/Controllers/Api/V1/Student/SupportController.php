<?php

namespace App\Http\Controllers\Api\V1\Student;

use App\Http\Controllers\Controller;
use App\Models\Faq;
use App\Models\SupportTicket;
use App\Exceptions\DomainException;
use App\Services\FeatureGate;
use App\Services\SettingsRepository;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class SupportController extends Controller
{
    public function __construct(
        protected SettingsRepository $settings,
        protected FeatureGate $features,
    ) {}

    public function overview(Request $request): JsonResponse
    {
        $institution = $this->settings->group('institution');

        $tickets = SupportTicket::query()
            ->where('user_id', $request->user()->getKey())
            ->orderByDesc('created_at')
            ->limit(20)
            ->get();

        return ApiResponse::item([
            'contact' => [
                'phone' => $institution['primary_phone'] ?? null,
                'whatsapp' => $institution['whatsapp'] ?? null,
                'email' => $institution['support_email'] ?? null,
                'hours' => $institution['support_hours'] ?? null,
            ],
            'faqs' => Faq::published()->limit(10)->get()->map(fn (Faq $faq) => [
                'id' => $faq->id,
                'question' => $faq->question,
                'answer' => $faq->answer,
            ])->all(),
            'tickets' => $tickets->map(fn (SupportTicket $ticket) => [
                'id' => $ticket->id,
                'reference' => $ticket->reference,
                'subject' => $ticket->subject,
                'status' => $ticket->status->value,
                'created_at' => $ticket->created_at->toIso8601String(),
                'resolved_at' => $ticket->resolved_at?->toIso8601String(),
            ])->all(),
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        if (! $this->features->supportTickets()) {
            throw DomainException::conflict(
                'Support tickets are turned off. Please use the phone or WhatsApp number on the support page.',
                'support_tickets_disabled',
            );
        }

        $data = $request->validate([
            'subject' => ['required', 'string', 'max:180'],
            'category' => ['nullable', 'string', 'max:40'],
            'message' => ['required', 'string', 'min:10', 'max:4000'],
        ]);

        $user = $request->user();

        $ticket = SupportTicket::create([
            'reference' => 'SUP-'.now()->format('Ymd').'-'.Str::upper(Str::random(5)),
            'user_id' => $user->getKey(),
            'name' => $user->name,
            'email' => $user->email,
            'mobile' => $user->mobile,
            'subject' => $data['subject'],
            'category' => $data['category'] ?? 'general',
            'message' => $data['message'],
            'source' => 'student',
            'ip_address' => $request->ip(),
        ]);

        return ApiResponse::item([
            'id' => $ticket->id,
            'reference' => $ticket->reference,
            'status' => $ticket->status->value,
        ], status: 201);
    }
}
