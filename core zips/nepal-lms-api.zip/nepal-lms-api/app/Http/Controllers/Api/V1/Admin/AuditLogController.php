<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

/** Read-only view of the audit trail. Entries are never editable. */
class AuditLogController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $entries = AuditLog::query()
            ->with('actor:id,name')
            ->when($request->filled('action'), fn ($query) => $query->where('action', 'like', $request->string('action')->value().'%'))
            ->when($request->filled('actor_id'), fn ($query) => $query->where('actor_id', $request->string('actor_id')->value()))
            ->when($request->filled('from'), fn ($query) => $query->where('occurred_at', '>=', $request->date('from')))
            ->when($request->filled('to'), fn ($query) => $query->where('occurred_at', '<=', $request->date('to')))
            ->orderByDesc('occurred_at')
            ->paginate($this->perPage(50));

        return ApiResponse::paginated($entries, fn (AuditLog $entry) => [
            'id' => $entry->id,
            'actor_label' => $entry->actor_label ?? $entry->actor?->name ?? 'System',
            'action' => $entry->action,
            'target_label' => $entry->target_label ?? '—',
            'occurred_at' => $entry->occurred_at->toIso8601String(),
            'reason' => $entry->reason,
        ]);
    }
}
