<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Enums\BatchStatus;
use App\Http\Controllers\Controller;
use App\Models\Batch;
use App\Models\User;
use App\Services\AuditLogger;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

class BatchController extends Controller
{
    public function __construct(protected AuditLogger $audit) {}

    public function index(Request $request): JsonResponse
    {
        $batches = Batch::query()
            ->with(['course:id,title', 'teachers:id,name'])
            ->withCount(['enrollments as students_count' => fn ($query) => $query->accessible()])
            ->when($request->filled('status'), fn ($query) => $query->where('status', $request->string('status')->value()))
            ->when($request->filled('course_id'), fn ($query) => $query->where('course_id', $request->string('course_id')->value()))
            ->orderByDesc('start_at')
            ->paginate($this->perPage(100));

        return ApiResponse::paginated($batches, fn (Batch $batch) => $this->payload($batch));
    }

    public function show(Batch $batch): JsonResponse
    {
        $batch->load(['course:id,title', 'teachers:id,name'])
            ->loadCount(['enrollments as students_count' => fn ($query) => $query->accessible()]);

        return ApiResponse::item($this->payload($batch));
    }

    public function store(Request $request): JsonResponse
    {
        $data = $this->validated($request);

        $batch = Batch::create(array_merge($data, [
            'code' => $data['code'] ?? 'B-'.Str::upper(Str::random(8)),
            'public_id' => (string) Str::uuid(),
            'created_by' => $request->user()->getKey(),
        ]));

        $this->syncTeachers($batch, $data['teacher_ids'] ?? null);

        $this->audit->log('batch.created', $batch, $request->user());

        return ApiResponse::item(['id' => $batch->id], status: 201);
    }

    public function update(Request $request, Batch $batch): JsonResponse
    {
        $data = $this->validated($request, $batch);

        $batch->fill(collect($data)->except('teacher_ids')->all())->save();

        if (array_key_exists('teacher_ids', $data)) {
            $this->syncTeachers($batch, $data['teacher_ids']);
        }

        $this->audit->log('batch.updated', $batch, $request->user(), properties: ['fields' => array_keys($data)]);

        return ApiResponse::item(['id' => $batch->id]);
    }

    protected function payload(Batch $batch): array
    {
        return [
            'id' => $batch->id,
            'title' => $batch->title,
            'course_title' => $batch->course?->title ?? 'Course removed',
            'teacher_name' => $batch->teachers->first()?->name,
            'schedule_summary' => $batch->schedule_summary,
            'students_count' => (int) ($batch->students_count ?? 0),
            'capacity' => (int) ($batch->capacity ?? 0),
            'start_at' => $batch->start_at?->toIso8601String(),
            'end_at' => $batch->end_at?->toIso8601String(),
            'status' => $batch->status->value,
        ];
    }

    /** Only users who actually hold the teacher role may be assigned. */
    protected function syncTeachers(Batch $batch, ?array $teacherIds): void
    {
        if ($teacherIds === null) {
            return;
        }

        $valid = User::query()
            ->whereIn('id', $teacherIds)
            ->withRole('teacher')
            ->pluck('id');

        $batch->teachers()->sync(
            $valid->mapWithKeys(fn ($id, $index) => [$id => ['is_lead' => $index === 0]])->all(),
        );
    }

    protected function validated(Request $request, ?Batch $existing = null): array
    {
        return $request->validate([
            'course_id' => [$existing ? 'sometimes' : 'required', 'string', Rule::exists('courses', 'id')->whereNull('deleted_at')],
            'title' => [$existing ? 'sometimes' : 'required', 'string', 'min:2', 'max:160'],
            'code' => ['sometimes', 'nullable', 'string', 'max:40', Rule::unique('batches', 'code')->ignore($existing?->getKey())->whereNull('deleted_at')],
            'status' => ['sometimes', Rule::in(BatchStatus::values())],
            'start_at' => ['sometimes', 'nullable', 'date'],
            'end_at' => ['sometimes', 'nullable', 'date', 'after_or_equal:start_at'],

            // Content access normally outlives the teaching period.
            'access_until' => ['sometimes', 'nullable', 'date', 'after_or_equal:end_at'],

            'schedule_summary' => ['sometimes', 'nullable', 'string', 'max:180'],
            'schedule_days' => ['sometimes', 'nullable', 'array', 'max:7'],
            'schedule_days.*' => ['string', 'max:12'],
            'class_start_time' => ['sometimes', 'nullable', 'date_format:H:i'],
            'class_end_time' => ['sometimes', 'nullable', 'date_format:H:i'],
            'price_npr' => ['sometimes', 'integer', 'min:0', 'max:10000000'],
            'capacity' => ['sometimes', 'nullable', 'integer', 'min:1', 'max:5000'],
            'teacher_ids' => ['sometimes', 'array', 'max:5'],
            'teacher_ids.*' => ['string', Rule::exists('users', 'id')->whereNull('deleted_at')],
        ]);
    }
}
