<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\Storage;

/** ApiTeacher, used by /teachers and /teachers/{slug}. */
class TeacherResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'slug' => $this->slug,
            'name' => $this->user?->name ?? 'Faculty member',
            'role' => $this->headline,
            'subjects' => $this->subjects ?? [],
            'experience_summary' => $this->experience_summary,
            'bio' => $this->bio,
            'avatar_url' => $this->avatar_path ? Storage::disk('public')->url($this->avatar_path) : null,
        ];
    }
}
