<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUlids;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;


class TestQuestion extends Model
{
    use HasFactory, HasUlids;

    protected $fillable = [
        'test_id',
        'order',
        'type',
        'prompt',
        'marks',
        'negative_marks',
        'explanation',
    ];

    protected function casts(): array
    {
        return [
            'type' => \App\Enums\QuestionType::class,
            'marks' => 'decimal:2',
            'negative_marks' => 'decimal:2',
        ];
    }

    public function test(): BelongsTo
    {
        return $this->belongsTo(Test::class);
    }

    public function options(): HasMany
    {
        return $this->hasMany(TestOption::class);
    }

    public function correctOptionIds(): array
    {
        return $this->options->where('is_correct', true)->pluck('id')->all();
    }

}
