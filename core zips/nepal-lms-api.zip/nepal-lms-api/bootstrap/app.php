<?php

use App\Http\Middleware\AssignRequestId;
use App\Http\Middleware\EnforceMaintenanceNotice;
use App\Http\Middleware\EnsureAccountIsUsable;
use App\Http\Middleware\EnsurePermission;
use App\Http\Middleware\EnsureRole;
use App\Http\Middleware\HandleIdempotentRequest;
use App\Http\Middleware\InjectResponseMeta;
use App\Http\Middleware\SecurityHeaders;
use App\Support\ApiExceptionRenderer;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        api: __DIR__.'/../routes/api.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware) {
        // Sanctum stateful cookie authentication for the Next.js browser client.
        $middleware->statefulApi();

        $middleware->api(prepend: [
            AssignRequestId::class,
        ]);

        // Applies to the signed media routes as well as the JSON API.
        $middleware->web(append: [SecurityHeaders::class]);
        $middleware->api(append: [SecurityHeaders::class]);

        $middleware->api(append: [
            InjectResponseMeta::class,
            EnforceMaintenanceNotice::class,
        ]);

        $middleware->alias([
            'account.usable' => EnsureAccountIsUsable::class,
            'role' => EnsureRole::class,
            'permission' => EnsurePermission::class,
            'idempotent' => HandleIdempotentRequest::class,
        ]);

        // The API is consumed by a JSON client only; never redirect to a login page.
        $middleware->redirectGuestsTo(fn () => null);
    })
    ->withExceptions(function (Exceptions $exceptions) {
        ApiExceptionRenderer::register($exceptions);
    })
    ->create();
