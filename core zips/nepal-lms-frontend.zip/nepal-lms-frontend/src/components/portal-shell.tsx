"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { NotificationBell } from "@/components/notification-bell";
import {
  Bell,
  BookOpen,
  CalendarDays,
  CheckSquare,
  ChevronDown,
  ClipboardCheck,
  CreditCard,
  FileBarChart,
  FileText,
  FolderTree,
  GraduationCap,
  Headphones,
  Home,
  LayoutDashboard,
  Library,
  LogOut,
  Menu,
  MessageSquare,
  MonitorPlay,
  ReceiptText,
  Search,
  Settings,
  ShieldCheck,
  SlidersHorizontal,
  UserRound,
  Users,
  Video,
  WalletCards,
  X,
  type LucideIcon,
} from "lucide-react";
import { useState } from "react";
import { Brand } from "@/components/brand";
import { Badge } from "@/components/ui";
import { browserRequest } from "@/lib/api/browser-client";
import { portalHomeByMachineRole } from "@/lib/auth/roles";
import { cn, initials } from "@/lib/utils";
import type { PortalRole, SessionUser } from "@/types/lms";

type NavItem = { label: string; href: string; icon: LucideIcon; permission?: string };

const navByRole: Record<PortalRole, NavItem[]> = {
  student: [
    { label: "Dashboard", href: "/student/dashboard", icon: LayoutDashboard },
    { label: "Explore Courses", href: "/student/explore", icon: Search, permission: "courses.view" },
    { label: "My Courses", href: "/student/courses", icon: BookOpen },
    { label: "Recorded Classes", href: "/student/recordings", icon: MonitorPlay, permission: "recordings.view" },
    { label: "PDFs & Resources", href: "/student/resources", icon: FileText, permission: "resources.view" },
    { label: "Tests", href: "/student/tests", icon: ClipboardCheck, permission: "tests.view" },
    { label: "Payments", href: "/student/payments", icon: CreditCard, permission: "payments.view" },
    { label: "Notifications", href: "/student/notifications", icon: Bell },
    { label: "Profile & Security", href: "/student/profile", icon: UserRound },
    { label: "Support", href: "/student/support", icon: Headphones },
  ],
  teacher: [
    { label: "Dashboard", href: "/teacher/dashboard", icon: LayoutDashboard },
    { label: "My Batches", href: "/teacher/batches", icon: BookOpen, permission: "batches.view" },
    { label: "Classes", href: "/teacher/classes", icon: CalendarDays, permission: "sessions.view" },
    { label: "Attendance", href: "/teacher/attendance", icon: CheckSquare, permission: "attendance.view" },
    { label: "Tests & Content", href: "/teacher/content", icon: Library },
    { label: "Announcements", href: "/teacher/announcements", icon: MessageSquare, permission: "announcements.manage" },
    { label: "Profile & Security", href: "/teacher/profile", icon: UserRound },
  ],
  staff: [
    { label: "Dashboard", href: "/staff/dashboard", icon: LayoutDashboard },
    { label: "Courses", href: "/staff/courses", icon: BookOpen, permission: "courses.view" },
    { label: "Students", href: "/staff/students", icon: Users, permission: "students.view" },
    { label: "Payment Submissions", href: "/staff/payment-submissions", icon: WalletCards, permission: "payments.view" },
    { label: "Enrollments", href: "/staff/enrollments", icon: GraduationCap, permission: "enrollments.view" },
    { label: "Account Assistance", href: "/staff/support-actions", icon: Headphones, permission: "students.manage" },
  ],
  accounting: [
    { label: "Dashboard", href: "/accounting/dashboard", icon: LayoutDashboard },
    { label: "Payments", href: "/accounting/payments", icon: WalletCards, permission: "payments.view" },
    { label: "Receipts", href: "/accounting/receipts", icon: ReceiptText, permission: "payments.view" },
    { label: "Adjustments & Refunds", href: "/accounting/adjustments", icon: CreditCard, permission: "payments.adjust" },
    { label: "Financial Reports", href: "/accounting/reports/collections", icon: FileBarChart, permission: "reports.view" },
  ],
  admin: [
    { label: "Dashboard", href: "/admin/dashboard", icon: LayoutDashboard },
    { label: "Courses", href: "/admin/courses", icon: BookOpen, permission: "courses.view" },
    { label: "Categories", href: "/admin/categories", icon: FolderTree, permission: "courses.view" },
    { label: "Batches", href: "/admin/batches", icon: CalendarDays, permission: "batches.view" },
    { label: "Users & Roles", href: "/admin/users", icon: Users, permission: "users.view" },
    { label: "Learning Operations", href: "/admin/learning-operations", icon: MonitorPlay },
    { label: "Finance Oversight", href: "/admin/finance", icon: WalletCards, permission: "payments.view" },
    { label: "Announcements", href: "/admin/announcements", icon: MessageSquare, permission: "announcements.manage" },
    { label: "Reports", href: "/admin/reports/academic", icon: FileBarChart, permission: "reports.view" },
    { label: "Platform", href: "/admin/platform", icon: SlidersHorizontal, permission: "settings.manage" },
    { label: "Classes", href: "/teacher/classes", icon: Video },
    { label: "Attendance", href: "/teacher/attendance", icon: ClipboardCheck },
    { label: "Content & PDFs", href: "/teacher/content", icon: FileText },
    { label: "Students", href: "/staff/students", icon: Users },
    { label: "Payments desk", href: "/accounting/payments", icon: CreditCard },
    { label: "Integrations", href: "/admin/integrations/zoom", icon: ShieldCheck, permission: "settings.manage" },
    { label: "Settings & Audit", href: "/admin/settings", icon: Settings, permission: "settings.manage" },
  ],
};

/**
 * Where the header search goes for each portal.
 *
 * A single global search index does not exist, and pretending otherwise was the
 * previous behaviour — a box that looked functional and did nothing. Each
 * portal instead searches the list its user actually looks people or content up
 * in, using the same ?q= filter those pages already support.
 */
const searchTarget: Record<PortalRole, string> = {
  student: "/student/explore",
  teacher: "/teacher/batches",
  staff: "/staff/students",
  accounting: "/accounting/payments",
  admin: "/admin/users",
};

const searchPlaceholder: Record<PortalRole, string> = {
  student: "Search courses",
  teacher: "Search your batches",
  staff: "Search students",
  accounting: "Search payments",
  admin: "Search users",
};

const roleLabels: Record<PortalRole, string> = {
  student: "Student",
  teacher: "Teacher",
  staff: "Enrollment Officer",
  accounting: "Accountant",
  admin: "Administrator",
};

const machineRoleLabels = {
  student: "Student",
  teacher: "Teacher",
  enrollment_officer: "Enrollment Officer",
  accountant: "Accountant",
  admin: "Administrator",
} as const;

const mobileNavByRole: Record<PortalRole, NavItem[]> = {
  student: [
    { label: "Home", href: "/student/dashboard", icon: Home },
    { label: "Explore", href: "/student/explore", icon: Search, permission: "courses.view" },
    { label: "Courses", href: "/student/courses", icon: BookOpen },
    { label: "Recordings", href: "/student/recordings", icon: MonitorPlay, permission: "recordings.view" },
    { label: "PDFs", href: "/student/resources", icon: FileText, permission: "resources.view" },
  ],
  teacher: [
    { label: "Home", href: "/teacher/dashboard", icon: Home },
    { label: "Batches", href: "/teacher/batches", icon: BookOpen, permission: "batches.view" },
    { label: "Classes", href: "/teacher/classes", icon: CalendarDays, permission: "sessions.view" },
    { label: "Attendance", href: "/teacher/attendance", icon: CheckSquare, permission: "attendance.view" },
    { label: "Profile", href: "/teacher/profile", icon: UserRound },
  ],
  staff: [
    { label: "Home", href: "/staff/dashboard", icon: Home },
    { label: "Courses", href: "/staff/courses", icon: BookOpen, permission: "courses.view" },
    { label: "Students", href: "/staff/students", icon: Users, permission: "students.view" },
    { label: "Payments", href: "/staff/payment-submissions", icon: WalletCards, permission: "payments.view" },
    { label: "Enrollments", href: "/staff/enrollments", icon: GraduationCap, permission: "enrollments.view" },
  ],
  accounting: navByRole.accounting,
  admin: navByRole.admin.slice(0, 5),
};

function userDetail(user: SessionUser, role: PortalRole): string {
  if (role === "student" && user.studentCode) return `Student ID ${user.studentCode}`;
  return user.email || user.mobile || roleLabels[role];
}

function isAllowed(user: SessionUser, item: NavItem): boolean {
  if (!item.permission) return true;
  return user.roles.includes("admin") || user.permissions.includes("*") || user.permissions.includes(item.permission);
}

export function PortalShell({
  role,
  user,
  mockMode,
  children,
}: {
  role: PortalRole;
  user: SessionUser;
  mockMode: boolean;
  children: React.ReactNode;
}) {
  const pathname = usePathname();
  const router = useRouter();
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [loggingOut, setLoggingOut] = useState(false);
  const nav = navByRole[role].filter((item) => isAllowed(user, item));
  const mobileNav = mobileNavByRole[role].filter((item) => isAllowed(user, item)).slice(0, 5);

  const isActive = (href: string) => pathname === href || pathname.startsWith(`${href}/`);

  async function logout() {
    if (mockMode) {
      router.push("/");
      return;
    }
    setLoggingOut(true);
    try {
      await browserRequest<void>({ url: "/api/v1/auth/logout", method: "POST" });
    } finally {
      window.location.assign("/login");
    }
  }

  const navigation = (onNavigate?: () => void) =>
    nav.map((item) => {
      const Icon = item.icon;
      const active = isActive(item.href);
      return (
        <Link
          key={item.href}
          href={item.href}
          onClick={onNavigate}
          aria-current={active ? "page" : undefined}
          className={cn(
            "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-semibold transition-colors",
            active ? "bg-white text-brand-950 shadow-sm" : "text-slate-300 hover:bg-white/10 hover:text-white",
          )}
        >
          <Icon className="h-[18px] w-[18px] shrink-0" aria-hidden="true" />
          <span>{item.label}</span>
        </Link>
      );
    });

  return (
    <div className="min-h-screen bg-canvas">
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-[268px] border-r border-slate-800 bg-brand-950 lg:flex lg:flex-col">
        <div className="border-b border-white/10 px-5 py-5">
          <Brand href={`/${role}/dashboard`} light />
        </div>
        <div className="px-5 pt-5">
          <div className="rounded-xl border border-white/10 bg-white/[0.06] p-3">
            <div className="flex items-center gap-3">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-white text-xs font-bold text-brand-900">{initials(user.name)}</div>
              <div className="min-w-0">
                <p className="truncate text-sm font-semibold text-white">{user.name}</p>
                <p className="truncate text-xs text-blue-200">{roleLabels[role]}</p>
              </div>
            </div>
          </div>
        </div>
        <nav className="soft-scrollbar mt-4 flex-1 overflow-y-auto px-3 pb-5" aria-label={`${roleLabels[role]} navigation`}>
          <p className="px-3 pb-2 pt-3 text-[10px] font-bold uppercase tracking-[0.18em] text-slate-500">Workspace</p>
          <div className="space-y-1">{navigation()}</div>
        </nav>
        <div className="border-t border-white/10 p-4">
          <button
            type="button"
            onClick={logout}
            disabled={loggingOut}
            className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-semibold text-slate-300 hover:bg-white/10 hover:text-white disabled:opacity-60"
          >
            <LogOut className="h-[18px] w-[18px]" />{loggingOut ? "Signing out…" : mockMode ? "Exit preview" : "Sign out"}
          </button>
        </div>
      </aside>

      {drawerOpen ? (
        <div className="fixed inset-0 z-50 lg:hidden">
          <button type="button" className="absolute inset-0 bg-slate-950/55" onClick={() => setDrawerOpen(false)} aria-label="Close navigation" />
          <aside className="relative flex h-full w-[300px] max-w-[86vw] flex-col bg-brand-950 shadow-float">
            <div className="flex items-center justify-between border-b border-white/10 p-4">
              <Brand href={`/${role}/dashboard`} light />
              <button type="button" onClick={() => setDrawerOpen(false)} className="flex h-10 w-10 items-center justify-center rounded-lg text-white hover:bg-white/10" aria-label="Close menu"><X className="h-5 w-5" /></button>
            </div>
            <div className="border-b border-white/10 p-4">
              <p className="font-semibold text-white">{user.name}</p>
              <p className="mt-1 text-xs text-blue-200">{userDetail(user, role)}</p>
            </div>
            <nav className="flex-1 overflow-y-auto p-3"><div className="space-y-1">{navigation(() => setDrawerOpen(false))}</div></nav>
          </aside>
        </div>
      ) : null}

      <div className="lg:pl-[268px]">
        <header className="sticky top-0 z-30 flex h-16 items-center justify-between border-b border-slate-200 bg-white/95 px-4 backdrop-blur sm:px-6 lg:px-8">
          <div className="flex items-center gap-3">
            <button type="button" onClick={() => setDrawerOpen(true)} className="flex h-10 w-10 items-center justify-center rounded-lg border border-slate-200 text-slate-700 lg:hidden" aria-label="Open navigation"><Menu className="h-5 w-5" /></button>
            <form
              action={searchTarget[role]}
              method="get"
              role="search"
              className="hidden max-w-sm items-center gap-2 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm md:flex md:w-72"
            >
              <Search className="h-4 w-4 shrink-0 text-slate-400" />
              <input
                type="search"
                name="q"
                placeholder={searchPlaceholder[role]}
                aria-label={searchPlaceholder[role]}
                className="w-full bg-transparent text-sm text-slate-700 outline-none placeholder:text-slate-400"
              />
            </form>
            <div className="md:hidden">
              <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">{roleLabels[role]}</p>
              <p className="text-sm font-bold text-slate-900">{user.name}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {mockMode ? <Badge tone="blue" className="hidden sm:inline-flex">Preview data</Badge> : null}
            {role === "student" ? (
              <NotificationBell href="/student/notifications" />
            ) : (
              <Link href={`/${role}/dashboard`} className="relative flex h-10 w-10 items-center justify-center rounded-lg text-slate-600 hover:bg-slate-100" aria-label="Dashboard">
                <Bell className="h-5 w-5" />
              </Link>
            )}
            <div className="relative">
              <button type="button" onClick={() => setProfileOpen((value) => !value)} className="flex items-center gap-2 rounded-lg p-1.5 hover:bg-slate-100" aria-expanded={profileOpen} aria-haspopup="menu">
                <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand-100 text-xs font-bold text-brand-900">{initials(user.name)}</span>
                <span className="hidden text-left xl:block"><span className="block max-w-36 truncate text-sm font-semibold text-slate-900">{user.name}</span><span className="block max-w-44 truncate text-xs text-slate-500">{userDetail(user, role)}</span></span>
                <ChevronDown className="hidden h-4 w-4 text-slate-400 sm:block" />
              </button>
              {profileOpen ? (
                <div className="absolute right-0 mt-2 w-72 rounded-xl border border-slate-200 bg-white p-2 shadow-float" role="menu">
                  <div className="px-3 py-2">
                    <p className="truncate text-sm font-bold text-slate-950">{user.name}</p>
                    <p className="mt-1 truncate text-xs text-slate-500">{userDetail(user, role)}</p>
                  </div>
                  {user.roles.length > 1 ? (
                    <>
                      <div className="my-2 border-t border-slate-100" />
                      <p className="px-3 py-2 text-xs font-bold uppercase tracking-wider text-slate-400">Switch workspace</p>
                      {user.roles.map((machineRole) => (
                        <Link key={machineRole} href={portalHomeByMachineRole[machineRole]} className="flex items-center justify-between rounded-lg px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">
                          {machineRoleLabels[machineRole]}<ShieldCheck className="h-4 w-4 text-slate-400" />
                        </Link>
                      ))}
                    </>
                  ) : null}
                  <div className="my-2 border-t border-slate-100" />
                  <button type="button" onClick={logout} className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"><LogOut className="h-4 w-4" />{mockMode ? "Exit preview" : "Sign out"}</button>
                </div>
              ) : null}
            </div>
          </div>
        </header>

        <main id="main-content" className="mx-auto max-w-[1500px] px-4 py-6 pb-24 sm:px-6 sm:py-8 lg:px-8 lg:pb-10">
          {children}
        </main>
      </div>

      <nav className="fixed inset-x-0 bottom-0 z-40 grid h-[70px] border-t border-slate-200 bg-white px-1 pb-[env(safe-area-inset-bottom)] shadow-[0_-8px_24px_rgba(15,23,42,0.06)] lg:hidden" style={{ gridTemplateColumns: `repeat(${mobileNav.length}, minmax(0, 1fr))` }} aria-label="Mobile navigation">
        {mobileNav.map((item) => {
          const Icon = item.icon;
          const active = isActive(item.href);
          return (
            <Link key={item.href} href={item.href} aria-current={active ? "page" : undefined} className={cn("flex min-w-0 flex-col items-center justify-center gap-1 px-1 text-[10px] font-semibold", active ? "text-brand-700" : "text-slate-500")}>
              <Icon className={cn("h-5 w-5", active && "stroke-[2.5]")} />
              <span className="max-w-full truncate">{item.label}</span>
            </Link>
          );
        })}
      </nav>
    </div>
  );
}
