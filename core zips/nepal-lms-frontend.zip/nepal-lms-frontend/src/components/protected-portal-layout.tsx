import { PortalShell } from "@/components/portal-shell";
import { SessionIntegrity } from "@/components/auth/session-integrity";
import { SessionProvider } from "@/components/auth/session-provider";
import { requirePortalAccess } from "@/lib/auth/server";
import { isMockDataEnabled } from "@/lib/data/config";
import type { PortalRole } from "@/types/lms";

export async function ProtectedPortalLayout({
  role,
  children,
}: {
  role: PortalRole;
  children: React.ReactNode;
}) {
  const user = await requirePortalAccess(role);
  return (
    <SessionProvider user={user}>
      {/* Back-button after sign-out must not reveal the previous session. */}
      <SessionIntegrity />
      <PortalShell role={role} user={user} mockMode={isMockDataEnabled()}>
        {children}
      </PortalShell>
    </SessionProvider>
  );
}
