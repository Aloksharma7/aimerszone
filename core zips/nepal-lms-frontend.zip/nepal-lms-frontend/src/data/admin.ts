export const adminBatches = [
  {
    id: "batch-micro-evening-2083",
    name: "Evening Batch · 2083",
    course: "BBS First Year Microeconomics",
    teacher: "Aarav Sharma",
    schedule: "Sun–Thu · 7:00–8:15 PM",
    students: 64,
    capacity: 80,
    startDate: "17 Aug 2026",
    endDate: "15 Dec 2026",
    status: "Upcoming",
  },
  {
    id: "batch-cmat-morning-2083",
    name: "Morning Batch · 2083",
    course: "CMAT Preparation Foundation",
    teacher: "Maya Gurung",
    schedule: "Sun–Fri · 6:30–8:00 AM",
    students: 72,
    capacity: 90,
    startDate: "24 Aug 2026",
    endDate: "28 Feb 2027",
    status: "Upcoming",
  },
  {
    id: "batch-banking-evening-2083",
    name: "Evening Batch · Running",
    course: "Banking Exam Complete Preparation",
    teacher: "Nischal Karki",
    schedule: "Sun–Fri · 6:00–7:30 PM",
    students: 96,
    capacity: 100,
    startDate: "3 Aug 2026",
    endDate: "31 Mar 2027",
    status: "Ongoing",
  },
  {
    id: "batch-accountancy-weekend",
    name: "Weekend Revision Batch",
    course: "Class 12 Accountancy Revision",
    teacher: "Srijana Adhikari",
    schedule: "Fri–Sat · 8:00–10:00 AM",
    students: 38,
    capacity: 60,
    startDate: "21 Aug 2026",
    endDate: "20 Nov 2026",
    status: "Upcoming",
  },
  {
    id: "batch-study-skills-free",
    name: "Self-paced + Live Orientation",
    course: "Free Study Skills Orientation",
    teacher: "Maya Gurung",
    schedule: "Open now · Monthly Q&A",
    students: 312,
    capacity: 500,
    startDate: "Open",
    endDate: "Rolling access",
    status: "Ongoing",
  },
  {
    id: "batch-bba-economics-draft",
    name: "BBA Economics · September",
    course: "BBA Business Economics",
    teacher: "Not assigned",
    schedule: "Schedule required",
    students: 0,
    capacity: 60,
    startDate: "7 Sep 2026",
    endDate: "Not set",
    status: "Draft",
  },
];

export const adminUsers = [
  { id: "USR-STU-1001", name: "Riya Thapa", email: "riya@example.test", phone: "+977 98XXXX1001", role: "Student", status: "Active", lastSeen: "8 min ago", mfa: "Not enabled" },
  { id: "USR-STU-1002", name: "Suman Rai", email: "suman@example.test", phone: "+977 98XXXX1002", role: "Student", status: "Pending payment", lastSeen: "42 min ago", mfa: "Not enabled" },
  { id: "USR-TCH-2001", name: "Aarav Sharma", email: "teacher.one@example.test", phone: "+977 98XXXX2001", role: "Teacher", status: "Active", lastSeen: "5 min ago", mfa: "Enabled" },
  { id: "USR-TCH-2002", name: "Maya Gurung", email: "teacher.two@example.test", phone: "+977 98XXXX2002", role: "Teacher", status: "Active", lastSeen: "26 min ago", mfa: "Enabled" },
  { id: "USR-STF-3001", name: "Sanjay Bista", email: "officer@example.test", phone: "+977 98XXXX3001", role: "Enrollment Officer", status: "Active", lastSeen: "Now", mfa: "Enabled" },
  { id: "USR-ACC-4001", name: "Nisha K.C.", email: "accountant@example.test", phone: "+977 98XXXX4001", role: "Accountant", status: "Active", lastSeen: "Now", mfa: "Enabled" },
  { id: "USR-ADM-5001", name: "System Administrator", email: "admin@example.test", phone: "+977 98XXXX5001", role: "Administrator", status: "Active", lastSeen: "Now", mfa: "Enabled" },
  { id: "USR-STU-1004", name: "Prabin Sah", email: "prabin@example.test", phone: "+977 98XXXX1004", role: "Student", status: "Suspended", lastSeen: "3 days ago", mfa: "Not enabled" },
];

export const roleDefinitions = [
  {
    id: "role-student",
    name: "Student",
    users: 1248,
    description: "Access only to owned enrollments, classes, recordings, tests, payments and profile.",
    permissions: ["View own learning", "Join authorized classes", "Submit payment proof", "Take tests"],
    protected: true,
  },
  {
    id: "role-teacher",
    name: "Teacher",
    users: 18,
    description: "Manage teaching work only for assigned batches and sessions.",
    permissions: ["Manage assigned classes", "Finalize attendance", "Publish assigned content", "Create tests"],
    protected: true,
  },
  {
    id: "role-enrollment",
    name: "Enrollment Officer",
    users: 6,
    description: "Create students and payment submissions without approving money or access.",
    permissions: ["Create student", "Submit payment evidence", "Request enrollment", "Assist account access"],
    protected: true,
  },
  {
    id: "role-accountant",
    name: "Accountant",
    users: 4,
    description: "Review money evidence, issue receipts and manage audited adjustments.",
    permissions: ["Review payments", "Issue receipts", "Approve refunds", "View finance reports"],
    protected: true,
  },
  {
    id: "role-admin",
    name: "Administrator",
    users: 2,
    description: "Configure the platform while all authorization remains enforced by Laravel policies.",
    permissions: ["Manage catalogue", "Manage users and roles", "Configure integrations", "View audit logs"],
    protected: true,
  },
];

export const adminAnnouncements = [
  { id: "ANN-2083-041", title: "Wednesday class moved to 7:30 PM", audience: "Microeconomics Evening Batch", author: "Aarav Sharma", channel: "In-app + email", scheduled: "Published 9 Aug, 10:12 AM", status: "Published" },
  { id: "ANN-2083-040", title: "CMAT diagnostic opens Thursday", audience: "CMAT Morning Batch", author: "Maya Gurung", channel: "In-app", scheduled: "Scheduled 13 Aug, 6:00 AM", status: "Scheduled" },
  { id: "ANN-2083-039", title: "Payment verification service notice", audience: "All students", author: "System Administrator", channel: "In-app + SMS", scheduled: "Draft updated 8 Aug", status: "Draft" },
  { id: "ANN-2083-038", title: "New study skills resources", audience: "Free Learning", author: "Maya Gurung", channel: "In-app", scheduled: "Published 7 Aug, 8:30 PM", status: "Published" },
];

export const paymentMethods = [
  { id: "PM-ES-01", name: "eSewa", accountName: "Institution LMS", accountRef: "98XXXXXX01", instructions: "Pay the exact amount and upload the complete success screen.", status: "Active", sort: 1 },
  { id: "PM-KH-01", name: "Khalti", accountName: "Institution LMS", accountRef: "98XXXXXX02", instructions: "Include the transaction ID and payment date.", status: "Active", sort: 2 },
  { id: "PM-BK-01", name: "Bank transfer", accountName: "Institution LMS Pvt. Ltd.", accountRef: "Account ending 2083", instructions: "Upload a deposit slip or full mobile banking receipt.", status: "Active", sort: 3 },
  { id: "PM-CS-01", name: "Cash at office", accountName: "Main office", accountRef: "Receipt required", instructions: "Staff records the official receipt number during submission.", status: "Paused", sort: 4 },
];

export const academicReportRows = [
  { id: "AR-01", batch: "Microeconomics Evening", students: 64, attendance: "88%", testAverage: "72%", syllabus: "51%", recordings: "63%", followUp: 6 },
  { id: "AR-02", batch: "CMAT Morning", students: 72, attendance: "91%", testAverage: "68%", syllabus: "27%", recordings: "46%", followUp: 9 },
  { id: "AR-03", batch: "Banking Evening", students: 96, attendance: "84%", testAverage: "65%", syllabus: "32%", recordings: "41%", followUp: 15 },
  { id: "AR-04", batch: "Accountancy Weekend", students: 38, attendance: "93%", testAverage: "76%", syllabus: "18%", recordings: "30%", followUp: 3 },
  { id: "AR-05", batch: "Study Skills Free", students: 312, attendance: "—", testAverage: "61%", syllabus: "74%", recordings: "58%", followUp: 22 },
];

export const enrollmentReportRows = [
  { id: "ER-01", period: "4–10 Aug", new: 186, approved: 159, pending: 21, rejected: 6, free: 54, transfers: 3 },
  { id: "ER-02", period: "28 Jul–3 Aug", new: 148, approved: 132, pending: 9, rejected: 7, free: 38, transfers: 2 },
  { id: "ER-03", period: "21–27 Jul", new: 121, approved: 109, pending: 7, rejected: 5, free: 30, transfers: 1 },
  { id: "ER-04", period: "14–20 Jul", new: 96, approved: 88, pending: 4, rejected: 4, free: 24, transfers: 2 },
];

export const financeReportRows = [
  { id: "FR-01", date: "9 Aug 2026", transactions: 42, gross: 241500, refunds: 0, adjustments: -3500, net: 238000, pending: 18 },
  { id: "FR-02", date: "8 Aug 2026", transactions: 58, gross: 336800, refunds: -6200, adjustments: 0, net: 330600, pending: 12 },
  { id: "FR-03", date: "7 Aug 2026", transactions: 51, gross: 292400, refunds: 0, adjustments: -2800, net: 289600, pending: 9 },
  { id: "FR-04", date: "6 Aug 2026", transactions: 46, gross: 267500, refunds: -3500, adjustments: 0, net: 264000, pending: 11 },
  { id: "FR-05", date: "5 Aug 2026", transactions: 39, gross: 221200, refunds: 0, adjustments: 0, net: 221200, pending: 8 },
];

export const zoomMeetings = [
  { id: "ZM-DEMO-1001", batch: "Microeconomics Evening", topic: "Elasticity of Demand — Numerical Practice", scheduled: "9 Aug · 7:00 PM", host: "Aarav Sharma", providerState: "Synced", localState: "Ready" },
  { id: "ZM-DEMO-1002", batch: "CMAT Morning", topic: "Logical Reasoning: Series and Patterns", scheduled: "10 Aug · 6:30 AM", host: "Maya Gurung", providerState: "Synced", localState: "Ready" },
  { id: "ZM-DEMO-1003", batch: "Banking Evening", topic: "Simple and Compound Interest", scheduled: "11 Aug · 6:00 PM", host: "Nischal Karki", providerState: "Warning", localState: "Fallback configured" },
];

export const youtubeRecordings = [
  { id: "YT-DEMO-801", batch: "Microeconomics Evening", title: "Price Elasticity of Demand", videoId: "demo_elasticity_01", privacy: "Unlisted", access: "Enrolled students", published: "7 Aug 2026", state: "Available" },
  { id: "YT-DEMO-802", batch: "CMAT Morning", title: "Verbal Analogy Review", videoId: "demo_analogy_02", privacy: "Unlisted", access: "Enrolled students", published: "8 Aug 2026", state: "Available" },
  { id: "YT-DEMO-803", batch: "Banking Evening", title: "Banking Awareness — Session 4", videoId: "demo_banking_04", privacy: "Private", access: "Processing", published: "9 Aug 2026", state: "Pending" },
];
