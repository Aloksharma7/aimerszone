import { BookOpen, Plus, Users } from "lucide-react";
import { ButtonLink, MetricCard, PageHeader, Panel, ProgressBar, StatusBadge } from "@/components/ui";
import { getTeacherBatches } from "@/lib/data/teacher";

export default async function TeacherBatchesPage() {
  const batches = await getTeacherBatches();
  const ongoing = batches.filter((batch) => batch.status === "Ongoing").length;
  const upcoming = batches.filter((batch) => batch.status === "Upcoming").length;
  const students = batches.reduce((sum, batch) => sum + batch.students, 0);
  return <><PageHeader eyebrow="Teaching" title="My Batches" description="Only batches assigned to your teacher account are shown." /><div className="grid gap-4 sm:grid-cols-3"><MetricCard label="Ongoing" value={String(ongoing)} icon={BookOpen} tone="blue" /><MetricCard label="Upcoming" value={String(upcoming)} icon={Plus} tone="violet" /><MetricCard label="Students" value={String(students)} icon={Users} tone="green" /></div><div className="mt-6 grid gap-5 lg:grid-cols-2 xl:grid-cols-3">{batches.map((batch) => <Panel key={batch.id}><div className="flex items-center justify-between gap-3"><StatusBadge status={batch.status} /><span className="text-sm font-semibold text-slate-500">{batch.students} students</span></div><h2 className="mt-4 text-lg font-bold text-slate-950">{batch.course}</h2><p className="mt-1 text-sm font-semibold text-brand-700">{batch.batch}</p><dl className="mt-4 space-y-2 text-sm text-slate-500"><div className="flex justify-between gap-4"><dt>Schedule</dt><dd className="text-right font-medium text-slate-700">{batch.schedule}</dd></div><div className="flex justify-between gap-4"><dt>Next class</dt><dd className="text-right font-medium text-slate-700">{batch.nextClass}</dd></div></dl><div className="mt-5"><ProgressBar value={batch.progress} label="Syllabus coverage" /></div><ButtonLink href={`/teacher/batches/${batch.id}`} className="mt-5 w-full">Open batch workspace</ButtonLink></Panel>)}</div></>;
}
