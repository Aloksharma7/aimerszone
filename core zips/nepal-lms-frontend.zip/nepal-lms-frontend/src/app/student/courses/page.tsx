import { Clock3 } from "lucide-react";
import { CourseProgressCard } from "@/components/portal-components";
import { Badge, ButtonLink, EmptyState, PageHeader, Panel } from "@/components/ui";
import { getStudentEnrollments } from "@/lib/data/student";

export default async function StudentCoursesPage() {
  const enrollments = await getStudentEnrollments();
  const active = enrollments.filter((item) => !item.status || item.status === "active");
  const completed = enrollments.filter((item) => item.progress >= 100 && item.status !== "expired");
  const expired = enrollments.filter((item) => item.status === "expired");
  return (
    <>
      <PageHeader eyebrow="My learning" title="My Courses" description="Open active batches, review completed learning and understand expired access." actions={<ButtonLink href="/student/explore">Explore more courses</ButtonLink>} />
      <div className="no-scrollbar mb-5 flex gap-2 overflow-x-auto"><span className="rounded-full bg-brand-900 px-4 py-2 text-sm font-semibold text-white">Active · {active.length}</span><span className="rounded-full bg-white px-4 py-2 text-sm font-semibold text-slate-600 ring-1 ring-slate-200">Completed · {completed.length}</span><span className="rounded-full bg-white px-4 py-2 text-sm font-semibold text-slate-600 ring-1 ring-slate-200">Expired · {expired.length}</span></div>
      {active.length ? <div className="grid gap-5 lg:grid-cols-2 2xl:grid-cols-3">{active.map((item) => <CourseProgressCard key={item.id} enrollmentId={item.id} course={item.course} progress={item.progress} nextAction={item.nextAction} accessExpiry={item.accessExpiry} />)}</div> : <EmptyState title="No active courses" description="Your active enrollments will appear here after free enrollment or payment approval." action={<ButtonLink href="/student/explore">Explore courses</ButtonLink>} />}
      {expired.map((item) => <Panel key={item.id} className="mt-6 flex flex-col gap-4 sm:flex-row sm:items-center"><div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-slate-100 text-slate-600"><Clock3 className="h-5 w-5" /></div><div className="flex-1"><div className="flex flex-wrap items-center gap-2"><h2 className="font-bold text-slate-950">{item.course.title}</h2><Badge tone="slate">Expired</Badge></div><p className="mt-1 text-sm text-slate-500">Access ended {item.accessExpiry}</p></div><ButtonLink href="/student/support" variant="outline">Ask about access</ButtonLink></Panel>)}
    </>
  );
}
