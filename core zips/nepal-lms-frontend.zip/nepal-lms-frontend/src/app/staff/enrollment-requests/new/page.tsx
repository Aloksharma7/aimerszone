import { EnrollmentRequestForm } from "@/components/staff/operations-forms";
import { ButtonLink, PageHeader } from "@/components/ui";
import { getStaffCourses, getStaffStudents } from "@/lib/data/staff";

export default async function EnrollmentRequestPage() {
  const [students,courses]=await Promise.all([getStaffStudents(),getStaffCourses()]);
  return <><PageHeader eyebrow="Enrollment request" title="Request non-standard enrollment help" description="Use this only when a normal approved payment or free enrollment flow does not apply." actions={<ButtonLink href="/staff/enrollments" variant="outline">Cancel</ButtonLink>}/><EnrollmentRequestForm students={students} courses={courses}/></>;
}
