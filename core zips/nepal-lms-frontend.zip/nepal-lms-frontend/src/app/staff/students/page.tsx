import { Filter, Plus, Users } from "lucide-react";
import { ApiExportLink } from "@/components/api-actions";
import { ListFilters } from "@/components/list-filters";
import { DataTable } from "@/components/portal-components";
import { ButtonLink, MetricCard, PageHeader, Panel, StatusBadge } from "@/components/ui";
import { getStaffStudents } from "@/lib/data/staff";
import { buildQueryString, firstParam, matchesQuery, type PageSearchParams } from "@/lib/search-params";

export default async function StaffStudentsPage({ searchParams }: { searchParams: PageSearchParams }) {
  const raw = await searchParams;
  const q = firstParam(raw.q);
  const status = firstParam(raw.status);
  const students = await getStaffStudents();
  const filtered = students.filter((item) => matchesQuery(q, item.id, item.name, item.phone, item.email, item.course) && (!status || item.status === status));
  const active = students.filter((item) => item.status === "Active").length;
  const pending = students.filter((item) => item.status === "Pending").length;
  const exportQuery = buildQueryString({ q, status });

  return (
    <>
      <PageHeader eyebrow="Student management" title="Students" description="Create accounts, correct permitted identity fields and assist with access." actions={<><ApiExportLink href={`/api/v1/staff/students/export${exportQuery}`} label="Export" /><ButtonLink href="/staff/students/new"><Plus className="h-4 w-4" />Add student</ButtonLink></>} />
      <div className="grid gap-4 sm:grid-cols-3">
        <MetricCard label="Total records" value={String(students.length)} icon={Users} tone="blue" />
        <MetricCard label="Active" value={String(active)} icon={Filter} tone="green" />
        <MetricCard label="Pending" value={String(pending)} icon={Plus} tone="amber" />
      </div>
      <Panel className="mt-6">
        <ListFilters
          searchValue={q}
          searchPlaceholder="Search name, phone or ID"
          resetHref="/staff/students"
          fields={[{ name: "status", label: "Student status", value: status, options: [{ value: "", label: "All statuses" }, { value: "Active", label: "Active" }, { value: "Pending", label: "Pending" }, { value: "Suspended", label: "Suspended" }] }]}
        />
        <div className="mt-5"><DataTable rowKey="id" rows={filtered as unknown as Record<string, unknown>[]} columns={[{ key: "id", label: "Student ID" }, { key: "name", label: "Student" }, { key: "phone", label: "Phone" }, { key: "course", label: "Current / Intended Course" }, { key: "joined", label: "Created" }, { key: "status", label: "Status", render: (row) => <StatusBadge status={String(row.status)} /> }]} /></div>
      </Panel>
    </>
  );
}
