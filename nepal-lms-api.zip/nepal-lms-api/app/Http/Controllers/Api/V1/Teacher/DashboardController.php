<?php

namespace App\Http\Controllers\Api\V1\Teacher;

use App\Enums\BatchStatus;
use App\Enums\RecordingState;
use App\Http\Controllers\Controller;
use App\Models\Batch;
use App\Models\ClassSession;
use App\Models\Enrollment;
use App\Models\Recording;
use App\Models\Test;
use App\Services\AccessGuard;
use App\Services\SettingsRepository;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

/**
 * Teacher landing page.
 *
 * Scoped entirely to batches this teacher is assigned to — a teacher never
 * sees another teacher's cohort, even in aggregate counts.
 */
class DashboardController extends Controller
{
    use ResolvesTeacherScope;

    public function __construct(
        protected AccessGuard $guard,
        protected SettingsRepository $settings,
    ) {}

    public function __invoke(Request $request): JsonResponse
    {
        $user = $request->user();
        $batchIds = $this->guard->taughtBatchIds($user);

        $batches = Batch::query()
            ->whereIn('id', $batchIds ?: ['-'])
            ->with('course:id,title')
            ->withCount(['enrollments as students_count' => fn ($query) => $query->accessible()])
            ->get();

        $todaySessions = ClassSession::query()
            ->whereIn('batch_id', $batchIds ?: ['-'])
            ->whereBetween('starts_at', [now()->startOfDay(), now()->endOfDay()])
            ->with(['batch.course', 'teacher'])
            ->orderBy('starts_at')
            ->get();

        $nextSession = ClassSession::query()
            ->whereIn('batch_id', $batchIds ?: ['-'])
            ->upcoming()
            ->with(['batch.course', 'teacher'])
            ->first();

        return ApiResponse::item([
            'next_session' => $nextSession ? $this->sessionPayload($nextSession) : null,
            'metrics' => [
                'assigned_batches' => $batches->count(),
                'ongoing_batches' => $batches->where('status', BatchStatus::Ongoing)->count(),
                'upcoming_batches' => $batches->where('status', BatchStatus::Open)->count(),
                'classes_today' => $todaySessions->count(),
                'attendance_actions' => $this->pendingAttendanceQuery($batchIds)->count(),
                'active_students' => Enrollment::query()
                    ->whereIn('batch_id', $batchIds ?: ['-'])
                    ->accessible()
                    ->distinct('user_id')
                    ->count('user_id'),
            ],
            'today_sessions' => $todaySessions->map(fn (ClassSession $session) => $this->sessionPayload($session))->all(),
            'follow_ups' => $this->followUps($batchIds),
            'batches' => $batches->map(fn (Batch $batch) => $this->batchPayload($batch))->all(),
        ]);
    }

    /** Concrete items the teacher still owes, most time-sensitive first. */
    protected function followUps(array $batchIds): array
    {
        $items = [];

        foreach ($this->pendingAttendanceQuery($batchIds)->with('batch')->limit(5)->get() as $session) {
            $items[] = [
                'id' => 'attendance-'.$session->id,
                'title' => 'Finalize attendance: '.$session->topic,
                'detail' => ($session->batch?->title ?? 'Batch').' · ended '.$session->ends_at->diffForHumans(),
                'href' => '/teacher/attendance',
                'type' => 'attendance',
            ];
        }

        $unreleased = Recording::query()
            ->whereIn('batch_id', $batchIds ?: ['-'])
            ->where(fn ($query) => $query->whereNull('released_at')->orWhere('state', RecordingState::Processing->value))
            ->with('batch')
            ->limit(5)
            ->get();

        foreach ($unreleased as $recording) {
            $items[] = [
                'id' => 'recording-'.$recording->id,
                'title' => 'Release recording: '.$recording->title,
                'detail' => ($recording->batch?->title ?? 'Batch').' · not yet visible to students',
                'href' => '/teacher/batches/'.$recording->batch_id.'/recordings',
                'type' => 'recording',
            ];
        }

        $drafts = Test::query()
            ->whereIn('batch_id', $batchIds ?: ['-'])
            ->where('status', 'draft')
            ->with('batch')
            ->limit(5)
            ->get();

        foreach ($drafts as $test) {
            $items[] = [
                'id' => 'test-'.$test->id,
                'title' => 'Publish test: '.$test->title,
                'detail' => ($test->batch?->title ?? 'Batch').' · still a draft',
                'href' => '/teacher/tests/'.$test->id,
                'type' => 'test',
            ];
        }

        return array_slice($items, 0, 12);
    }
}
