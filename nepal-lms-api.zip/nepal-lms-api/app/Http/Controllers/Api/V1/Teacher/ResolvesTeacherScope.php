<?php

namespace App\Http\Controllers\Api\V1\Teacher;

use App\Enums\ClassSessionStatus;
use App\Models\Batch;
use App\Models\ClassSession;
use App\Models\Enrollment;
use Illuminate\Database\Eloquent\Builder;

/**
 * Shared payload shaping and scope checks for the teacher portal.
 *
 * Every controller here goes through resolveBatch()/resolveSession(), which
 * fail with 404 rather than 403 for a batch the teacher does not teach — an
 * unassigned teacher should not be able to confirm the record exists.
 */
trait ResolvesTeacherScope
{
    protected function resolveBatch(string $batchId, $user): Batch
    {
        abort_unless($this->guard->teachesBatch($user, $batchId) || $user->isAdmin(), 404);

        return Batch::with('course:id,title')->findOrFail($batchId);
    }

    protected function resolveSession(string $sessionId, $user): ClassSession
    {
        $session = ClassSession::with(['batch.course', 'teacher'])->findOrFail($sessionId);

        abort_unless($this->guard->teachesBatch($user, $session->batch_id) || $user->isAdmin(), 404);

        return $session;
    }

    protected function batchPayload(Batch $batch): array
    {
        $next = $batch->sessions()->upcoming()->first();

        return [
            'id' => $batch->id,
            'course_title' => $batch->course?->title ?? 'Course removed',
            'batch_title' => $batch->title,
            'students_count' => (int) ($batch->students_count ?? $batch->enrollments()->accessible()->count()),
            'schedule_summary' => $batch->schedule_summary ?? 'Schedule not set',
            'syllabus_progress_percent' => $this->syllabusProgress($batch),
            'next_class_at' => $next?->starts_at?->toIso8601String(),
            'next_class_label' => $next?->topic,
            'status' => $batch->status->value,
        ];
    }

    protected function sessionPayload(ClassSession $session, ?int $studentsCount = null): array
    {
        return [
            'id' => $session->id,
            'title' => $session->topic,
            'course_title' => $session->batch?->course?->title ?? 'Course removed',
            'batch_title' => $session->batch?->title ?? 'Batch removed',
            'teacher_name' => $session->teacher?->name,
            'starts_at' => $session->starts_at->toIso8601String(),
            'ends_at' => $session->ends_at->toIso8601String(),
            'status' => $session->status->value,
            'students_count' => $studentsCount ?? $session->batch?->enrollments()->accessible()->count() ?? 0,
            'instructions' => $session->description,
            'attendance_state' => $session->attendanceFinalized() ? 'finalized' : 'pending',

            // The host link is only offered once the class is close enough to
            // start; the endpoint re-checks this independently.
            'start_available' => $this->startAvailable($session),
        ];
    }

    protected function startAvailable(ClassSession $session): bool
    {
        if (in_array($session->status, [ClassSessionStatus::Cancelled, ClassSessionStatus::Completed], true)) {
            return false;
        }

        return now()->betweenIncluded(
            $session->starts_at->copy()->subMinutes(30),
            $session->ends_at->copy()->addMinutes(30),
        );
    }

    /** Average syllabus completion across the batch's active students. */
    protected function syllabusProgress(Batch $batch): int
    {
        return (int) round(
            Enrollment::query()
                ->where('batch_id', $batch->getKey())
                ->accessible()
                ->avg('syllabus_percent') ?? 0,
        );
    }

    /** Finished classes whose register has not been finalized. */
    protected function pendingAttendanceQuery(array $batchIds): Builder
    {
        return ClassSession::query()
            ->whereIn('batch_id', $batchIds ?: ['-'])
            ->where('ends_at', '<', now())
            ->whereNull('attendance_finalized_at')
            ->where('status', '!=', ClassSessionStatus::Cancelled->value)
            ->orderBy('ends_at');
    }
}
