<?php

namespace App\Http\Controllers\Api\V1\Staff;

use App\Enums\CourseStatus;
use App\Http\Controllers\Controller;
use App\Http\Resources\CourseDetailResource;
use App\Http\Resources\CourseSummaryResource;
use App\Models\Course;
use App\Services\AuditLogger;
use App\Support\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

/**
 * Catalogue editing for the enrollment office.
 *
 * Same underlying records as the admin controller, but reached through the
 * courses.create / courses.update / courses.publish permissions rather than
 * the administrator role.
 */
class CourseController extends Controller
{
    public function __construct(protected AuditLogger $audit) {}

    public function index(Request $request): JsonResponse
    {
        $courses = Course::query()
            ->with(['category', 'batches.teachers.teacherProfile'])
            ->withCount(['modules', 'enrollments', 'batches'])
            ->search($request->string('q')->value())
            ->orderByDesc('updated_at')
            ->paginate($this->perPage(100));

        return ApiResponse::paginated($courses, fn (Course $course) => array_merge(
            (new CourseSummaryResource($course))->toArray($request),
            [
                'enrollments_count' => (int) $course->enrollments_count,
                'batches_count' => (int) $course->batches_count,
                'owner_name' => $course->owner?->name ?? 'Enrollment Team',
                'updated_at' => $course->updated_at?->toIso8601String(),
            ],
        ));
    }

    public function show(Request $request, string $course): JsonResponse
    {
        $model = $this->resolve($course);

        $model->load(['category', 'modules.lessons', 'batches.teachers.teacherProfile'])->loadCount('modules');

        return ApiResponse::item(new CourseDetailResource($model));
    }

    public function store(Request $request): JsonResponse
    {
        $this->authorize('create', Course::class);

        $data = $this->validated($request);

        $course = Course::create(array_merge($data, [
            'slug' => $data['slug'] ?? Str::slug($data['title']),
            'code' => $data['code'] ?? Str::upper(Str::slug(Str::limit($data['title'], 20, ''), '_')),
            'status' => CourseStatus::Draft->value,
            'published' => false,
            'owner_id' => $request->user()->getKey(),
            'created_by' => $request->user()->getKey(),
            'updated_by' => $request->user()->getKey(),
        ]));

        $this->audit->log('course.created', $course, $request->user());

        return ApiResponse::item(['id' => $course->id, 'slug' => $course->slug], status: 201);
    }

    public function update(Request $request, string $course): JsonResponse
    {
        $model = $this->resolve($course);

        $this->authorize('update', $model);

        $data = $this->validated($request, $model);

        // Publishing is a separate permission from editing, so an officer who
        // may draft a course cannot necessarily put it on the public site.
        if (array_key_exists('published', $data)) {
            $this->authorize('publish', $model);

            $data['status'] = $data['published'] ? CourseStatus::Published->value : CourseStatus::Draft->value;
            $data['published_at'] = $data['published'] ? ($model->published_at ?? now()) : null;
        }

        $model->fill($data + ['updated_by' => $request->user()->getKey()])->save();

        $this->audit->log('course.updated', $model, $request->user(), properties: ['fields' => array_keys($data)]);

        return ApiResponse::item(['id' => $model->id, 'slug' => $model->slug]);
    }

    protected function resolve(string $identifier): Course
    {
        return Course::query()->where('id', $identifier)->orWhere('slug', $identifier)->firstOrFail();
    }

    protected function validated(Request $request, ?Course $existing = null): array
    {
        return $request->validate([
            'title' => [$existing ? 'sometimes' : 'required', 'string', 'min:2', 'max:180'],
            'slug' => ['sometimes', 'string', 'max:160', 'regex:/^[a-z0-9]+(?:-[a-z0-9]+)*$/', Rule::unique('courses', 'slug')->ignore($existing?->getKey())->whereNull('deleted_at')],
            'code' => ['sometimes', 'nullable', 'string', 'max:32', Rule::unique('courses', 'code')->ignore($existing?->getKey())->whereNull('deleted_at')],
            'category_id' => ['sometimes', 'nullable', 'string', Rule::exists('categories', 'id')],
            'short_description' => ['sometimes', 'nullable', 'string', 'max:500'],
            'description' => ['sometimes', 'nullable', 'string', 'max:20000'],
            'access_type' => [$existing ? 'sometimes' : 'required', Rule::in(['free', 'paid'])],
            'price_npr' => ['sometimes', 'integer', 'min:0', 'max:10000000'],
            'features' => ['sometimes', 'array', 'max:8'],
            'features.*' => ['string', Rule::in(['Live', 'Recordings', 'Tests', 'Notes'])],
            'published' => ['sometimes', 'boolean'],
        ]);
    }
}
