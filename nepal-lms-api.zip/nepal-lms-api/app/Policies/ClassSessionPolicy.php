<?php

namespace App\Policies;

use App\Models\ClassSession;
use App\Models\User;
use App\Services\AccessGuard;

class ClassSessionPolicy
{
    public function __construct(protected AccessGuard $guard) {}

    public function view(User $user, ClassSession $session): bool
    {
        return $this->guard->canReachBatch($user, $session->batch_id, 'sessions.view');
    }

    /** Only an enrolled student in the window may request a join destination. */
    public function join(User $user, ClassSession $session): bool
    {
        return $this->guard->studentCanAccessBatch($user, $session->batch_id);
    }

    public function manage(User $user, ClassSession $session): bool
    {
        return $user->hasPermission('sessions.manage')
            && ($this->guard->teachesBatch($user, $session->batch_id) || $user->isAdmin());
    }

    public function start(User $user, ClassSession $session): bool
    {
        return $this->manage($user, $session);
    }

    public function finalizeAttendance(User $user, ClassSession $session): bool
    {
        return $user->hasPermission('attendance.finalize')
            && ($this->guard->teachesBatch($user, $session->batch_id) || $user->isAdmin());
    }
}
