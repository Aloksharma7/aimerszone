<?php

namespace App\Policies;

use App\Models\User;

class UserPolicy
{
    public function viewAny(User $user): bool
    {
        return $user->hasPermission('users.view') || $user->hasPermission('students.view');
    }

    public function view(User $user, User $target): bool
    {
        return $user->is($target) || $user->hasPermission('users.view') || $user->hasPermission('students.view');
    }

    public function update(User $user, User $target): bool
    {
        return $user->hasPermission('users.manage');
    }

    /** Suspension, MFA reset and session revocation. */
    public function administer(User $user, User $target): bool
    {
        return $user->hasPermission('users.security') && ! $user->is($target);
    }
}
