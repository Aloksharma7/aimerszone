<?php

namespace App\Enums;

enum RoleKey: string
{
    case Student = 'student';
    case Teacher = 'teacher';
    case EnrollmentOfficer = 'enrollment_officer';
    case Accountant = 'accountant';
    case Admin = 'admin';

    public function label(): string
    {
        return match ($this) {
            self::Student => 'Student',
            self::Teacher => 'Teacher',
            self::EnrollmentOfficer => 'Enrollment officer',
            self::Accountant => 'Accountant',
            self::Admin => 'Admin',
        };
    }

    /** @return array<int, string> */
    public static function values(): array
    {
        return array_column(self::cases(), 'value');
    }

    public function portalHome(): string
    {
        return match ($this) {
            self::Student => '/student/dashboard',
            self::Teacher => '/teacher/dashboard',
            self::EnrollmentOfficer => '/staff/dashboard',
            self::Accountant => '/accounting/dashboard',
            self::Admin => '/admin/dashboard',
        };
    }

    /**
     * Highest privilege first. Used to pick portal_home when a user holds
     * more than one role.
     *
     * @return array<int, self>
     */
    public static function byPriority(): array
    {
        return [self::Admin, self::Accountant, self::EnrollmentOfficer, self::Teacher, self::Student];
    }
}
