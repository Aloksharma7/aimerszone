<?php

namespace Tests\Feature;

use App\Enums\RoleKey;
use PHPUnit\Framework\Attributes\DataProvider;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\Concerns\BuildsLmsFixtures;
use Tests\TestCase;

/**
 * Cross-portal checks: no role should be able to walk into another portal, and
 * a teacher should only reach the batches they actually teach.
 */
class PortalAuthorizationTest extends TestCase
{
    use BuildsLmsFixtures, RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seedPlatform();
    }

    public static function portalMatrix(): array
    {
        return [
            'student cannot open teacher portal' => [RoleKey::Student, '/api/v1/teacher/dashboard'],
            'student cannot open staff portal' => [RoleKey::Student, '/api/v1/staff/students'],
            'student cannot open accounting portal' => [RoleKey::Student, '/api/v1/accounting/dashboard'],
            'student cannot open admin portal' => [RoleKey::Student, '/api/v1/admin/dashboard'],
            'teacher cannot open accounting portal' => [RoleKey::Teacher, '/api/v1/accounting/payments'],
            'teacher cannot open admin settings' => [RoleKey::Teacher, '/api/v1/admin/settings'],
            'officer cannot open accounting portal' => [RoleKey::EnrollmentOfficer, '/api/v1/accounting/dashboard'],
            'officer cannot open admin users' => [RoleKey::EnrollmentOfficer, '/api/v1/admin/users'],
            'accountant cannot open teacher portal' => [RoleKey::Accountant, '/api/v1/teacher/dashboard'],
            'accountant cannot open staff students' => [RoleKey::Accountant, '/api/v1/staff/students'],
        ];
    }

    #[DataProvider('portalMatrix')]
    public function test_roles_cannot_cross_portal_boundaries(RoleKey $role, string $endpoint): void
    {
        $user = $this->makeUser($role);

        $this->actingAs($user)->getJson($endpoint)->assertForbidden();
    }

    public function test_an_unauthenticated_request_is_rejected_with_a_machine_code(): void
    {
        $this->getJson('/api/v1/student/dashboard')
            ->assertUnauthorized()
            ->assertJsonPath('code', 'unauthenticated');
    }

    public function test_a_teacher_cannot_read_a_batch_they_do_not_teach(): void
    {
        $batch = $this->makeBatch($this->makeCourse());
        $assigned = $this->makeUser(RoleKey::Teacher);
        $other = $this->makeUser(RoleKey::Teacher);

        $batch->teachers()->attach($assigned->getKey(), ['is_lead' => true]);

        $this->actingAs($other)
            ->getJson('/api/v1/teacher/batches/'.$batch->getKey())
            ->assertNotFound();

        $this->actingAs($assigned)
            ->getJson('/api/v1/teacher/batches/'.$batch->getKey())
            ->assertOk();
    }

    public function test_an_administrator_cannot_remove_their_own_administrator_role(): void
    {
        $admin = $this->makeUser(RoleKey::Admin);

        $this->actingAs($admin)
            ->patchJson('/api/v1/admin/users/'.$admin->getKey(), ['primary_role' => 'student'])
            ->assertStatus(409)
            ->assertJsonPath('code', 'self_demotion_blocked');
    }

    /**
     * Regression: the teacher's attendance screen offers a "Review" option that
     * the status enum rejected, so saving the whole register failed with a bare
     * validation error.
     */
    public function test_review_is_an_accepted_attendance_status_but_blocks_finalizing(): void
    {
        $batch = $this->makeBatch($this->makeCourse());
        $teacher = $this->makeUser(RoleKey::Teacher);
        $student = $this->makeUser(RoleKey::Student);

        $batch->teachers()->attach($teacher->getKey(), ['is_lead' => true]);
        $this->enroll($student, $batch);

        $session = \App\Models\ClassSession::create([
            'batch_id' => $batch->getKey(),
            'teacher_id' => $teacher->getKey(),
            'topic' => 'Past class',
            'status' => 'completed',
            'starts_at' => now()->subHours(3),
            'ends_at' => now()->subHours(2),
        ]);

        $payload = ['participants' => [[
            'student_id' => $student->getKey(),
            'attendance_status' => 'review',
            'override_reason' => 'Connection dropped, checking the provider report.',
        ]]];

        // Saving a draft with an undecided row is fine.
        $this->actingAs($teacher)
            ->putJson('/api/v1/teacher/classes/'.$session->getKey().'/attendance', $payload)
            ->assertOk();

        // Finalizing with one still undecided is not.
        $this->actingAs($teacher)
            ->postJson('/api/v1/teacher/classes/'.$session->getKey().'/attendance/finalize', $payload)
            ->assertStatus(422)
            ->assertJsonPath('code', 'attendance_undecided');
    }

    public function test_the_public_catalogue_hides_unpublished_courses(): void
    {
        $published = $this->makeCourse(['title' => 'Visible Course']);
        $draft = $this->makeCourse(['published' => false, 'status' => 'draft', 'title' => 'Hidden Course']);

        $response = $this->getJson('/api/v1/public/courses')->assertOk();

        $titles = collect($response->json('data'))->pluck('title');

        $this->assertTrue($titles->contains('Visible Course'));
        $this->assertFalse($titles->contains('Hidden Course'));

        $this->getJson('/api/v1/public/courses/'.$draft->slug)->assertNotFound();
    }
}
