<?php

namespace Tests\Feature;

use App\Enums\RoleKey;
use App\Services\SettingsRepository;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\Concerns\BuildsLmsFixtures;
use Tests\TestCase;

/**
 * The promise that everything is administrator-controlled: a settings change
 * must actually take effect on the next request, without a deployment.
 */
class AdminConfigurationTest extends TestCase
{
    use BuildsLmsFixtures, RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seedPlatform();
    }

    public function test_changing_the_institution_name_reaches_the_public_endpoint(): void
    {
        $admin = $this->makeUser(RoleKey::Admin);

        $this->actingAs($admin)->patchJson('/api/v1/admin/settings', [
            'institution' => [
                'name' => 'Janakpur Study Centre',
                'support_email' => 'help@janakpur.test',
            ],
        ])->assertOk();

        $this->getJson('/api/v1/public/settings')
            ->assertOk()
            ->assertJsonPath('data.institution_name', 'Janakpur Study Centre')
            ->assertJsonPath('data.support.email', 'help@janakpur.test');

        $this->assertDatabaseHas('audit_logs', ['action' => 'settings.updated']);
    }

    public function test_maintenance_mode_pauses_writes_but_leaves_reads_open(): void
    {
        $settings = app(SettingsRepository::class);
        $settings->set('operations', 'maintenance_notice', true);

        $batch = $this->makeBatch($this->makeCourse());
        $student = $this->makeUser(RoleKey::Student);
        $this->enroll($student, $batch);

        // Students keep their information; only state changes are paused.
        $this->actingAs($student)->getJson('/api/v1/student/dashboard')->assertOk();

        $this->actingAs($student)
            ->postJson('/api/v1/student/support-tickets', [
                'subject' => 'Question about my batch',
                'message' => 'I would like to ask about the class schedule.',
            ])
            ->assertStatus(503)
            ->assertJsonPath('code', 'maintenance_mode');
    }

    public function test_an_administrator_still_works_during_maintenance(): void
    {
        app(SettingsRepository::class)->set('operations', 'maintenance_notice', true);

        $admin = $this->makeUser(RoleKey::Admin);

        $this->actingAs($admin)
            ->patchJson('/api/v1/admin/settings', ['operations' => ['maintenance_notice' => false]])
            ->assertOk();

        $this->assertFalse(app(SettingsRepository::class)->bool('operations.maintenance_notice'));
    }

    public function test_the_administrator_role_cannot_be_edited_into_a_weaker_one(): void
    {
        $admin = $this->makeUser(RoleKey::Admin);
        $role = \App\Models\Role::where('key', 'admin')->firstOrFail();

        $this->actingAs($admin)
            ->patchJson('/api/v1/admin/roles/'.$role->getKey(), ['permissions' => ['courses.view']])
            ->assertStatus(409)
            ->assertJsonPath('code', 'role_protected');
    }

    public function test_an_idempotency_key_replays_instead_of_repeating_the_action(): void
    {
        $admin = $this->makeUser(RoleKey::Admin);
        $key = 'test-key-'.uniqid();

        $payload = ['institution' => ['name' => 'Replay Institute']];

        $first = $this->actingAs($admin)
            ->withHeaders(['Idempotency-Key' => $key])
            ->patchJson('/api/v1/admin/settings', $payload)
            ->assertOk();

        $second = $this->actingAs($admin)
            ->withHeaders(['Idempotency-Key' => $key])
            ->patchJson('/api/v1/admin/settings', $payload)
            ->assertOk();

        $this->assertSame('true', $second->headers->get('Idempotent-Replay'));

        // The same key with a different body is a mistake, not a retry.
        $this->actingAs($admin)
            ->withHeaders(['Idempotency-Key' => $key])
            ->patchJson('/api/v1/admin/settings', ['institution' => ['name' => 'Different Name']])
            ->assertStatus(409)
            ->assertJsonPath('code', 'idempotency_key_reuse');
    }
}
