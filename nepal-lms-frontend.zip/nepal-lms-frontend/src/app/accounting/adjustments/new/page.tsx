import { AccountingAdjustmentForm } from "@/components/accounting/adjustment-form";
import { PageHeader } from "@/components/ui";
import { getSessionUser, requirePermission } from "@/lib/auth/server";

export default async function NewAccountingAdjustmentPage() {
  const user = await getSessionUser("accountant");
  if (user) await requirePermission(user, "payments.adjust");
  return <><PageHeader back={{ href: "/accounting/adjustments", label: "All adjustments" }} eyebrow="Financial corrections" title="New adjustment" description="Create a separate, auditable financial action against an authoritative payment record." /><AccountingAdjustmentForm /></>;
}
