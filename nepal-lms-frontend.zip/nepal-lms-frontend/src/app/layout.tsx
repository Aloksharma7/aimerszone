import type { Metadata } from "next";
import "./globals.css";
import { siteConfig } from "@/lib/site";
import { AppProviders } from "@/providers/app-providers";

export const metadata: Metadata = {
  title: {
    default: `${siteConfig.name} — Learn with a clear plan`,
    template: `%s | ${siteConfig.name}`,
  },
  description: siteConfig.tagline,
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>
        <a
          href="#main-content"
          className="sr-only z-[100] rounded-lg bg-white px-4 py-3 font-semibold text-brand-900 focus:not-sr-only focus:fixed focus:left-4 focus:top-4"
        >
          Skip to content
        </a>
        <AppProviders>{children}</AppProviders>
      </body>
    </html>
  );
}
