import { notFound } from "next/navigation";
import { FileVideo, Plus, Youtube } from "lucide-react";
import { ListFilters } from "@/components/list-filters";
import { TeacherRecordingForm } from "@/components/teacher/teacher-actions";
import { ButtonLink, PageHeader, Panel, StatusBadge } from "@/components/ui";
import { getSessionUser, requirePermission } from "@/lib/auth/server";
import { getTeacherBatch, getTeacherBatchRecordings } from "@/lib/data/teacher";
import { firstParam, matchesQuery, type PageSearchParams } from "@/lib/search-params";

export default async function TeacherRecordingsPage({ params, searchParams }: { params: Promise<{ batchId: string }>; searchParams: PageSearchParams }) {
  const [{ batchId }, raw] = await Promise.all([params, searchParams]);
  const q = firstParam(raw.q);
  const user = await getSessionUser("teacher");
  if (!user) notFound();
  await requirePermission(user, "recordings.manage");
  const [detail, items] = await Promise.all([getTeacherBatch(batchId), getTeacherBatchRecordings(batchId)]);
  if (!detail) notFound();
  const filtered = items.filter((item) => matchesQuery(q, item.id, item.title, item.module, item.teacher, item.state));

  return (
    <>
      <PageHeader eyebrow="Academic content" title="Recordings" description={`${detail.batch.course} · ${detail.batch.batch}`} actions={<ButtonLink href={`/teacher/batches/${encodeURIComponent(batchId)}/recordings#add-recording`}><Plus className="h-4 w-4" />Add recording</ButtonLink>} />
      <div className="grid gap-6 xl:grid-cols-[1fr_360px]">
        <Panel>
          <h2 className="text-xl font-bold text-slate-950">Released recordings</h2>
          <div className="mt-4"><ListFilters searchValue={q} searchPlaceholder="Search recording or module" resetHref={`/teacher/batches/${encodeURIComponent(batchId)}/recordings`} /></div>
          <div className="mt-5 divide-y divide-slate-100 rounded-xl border border-slate-200">
            {filtered.length ? filtered.map((item) => <div key={item.id} className="flex flex-col gap-4 p-4 sm:flex-row sm:items-center"><div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-red-50 text-red-700"><FileVideo className="h-5 w-5" /></div><div className="flex-1"><div className="flex flex-wrap items-center gap-2"><h3 className="font-semibold text-slate-900">{item.title}</h3><StatusBadge status={item.state === "Processing" ? "Processing" : "Published"} /></div><p className="mt-1 text-sm text-slate-500">{item.module} · {item.date} · {item.duration}</p><p className="mt-1 text-xs text-slate-400">Changes use a versioned recording update endpoint; published items remain auditable.</p></div></div>) : <p className="p-5 text-sm text-slate-500">No recordings match this search.</p>}
          </div>
        </Panel>
        <aside id="add-recording"><Panel><div className="flex h-11 w-11 items-center justify-center rounded-xl bg-red-50 text-red-700"><Youtube className="h-6 w-6" /></div><h2 className="mt-5 text-lg font-bold text-slate-950">Add recording</h2><TeacherRecordingForm batchId={batchId} /></Panel></aside>
      </div>
    </>
  );
}
