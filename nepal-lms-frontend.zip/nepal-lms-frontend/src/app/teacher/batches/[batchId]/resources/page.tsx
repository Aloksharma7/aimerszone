import { ResourceManager } from "@/components/teacher/resource-manager";
import { PageHeader } from "@/components/ui";
import { getBatchResources, getTeacherBatch } from "@/lib/data/teacher";

export default async function BatchResourcesPage({ params }: { params: Promise<{ batchId: string }> }) {
  const { batchId } = await params;
  const [batch, resources] = await Promise.all([getTeacherBatch(batchId), getBatchResources(batchId)]);

  return (
    <>
      <PageHeader
        eyebrow={batch ? `${batch.course} · ${batch.batch}` : "Batch"}
        title="Notes and resources"
        description="Upload PDFs and notes for this batch. Staged files stay hidden until you release them."
      />
      <ResourceManager batchId={batchId} resources={resources} />
    </>
  );
}
