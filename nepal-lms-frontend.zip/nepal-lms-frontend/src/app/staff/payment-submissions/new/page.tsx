import { PaymentSubmissionForm } from "@/components/staff/operations-forms";
import { ButtonLink, PageHeader } from "@/components/ui";
import { getStaffCourses, getStaffStudents } from "@/lib/data/staff";

export default async function NewStaffPaymentSubmissionPage() {
  const [students,courses]=await Promise.all([getStaffStudents(),getStaffCourses()]);
  return <><PageHeader back={{ href: "/staff/payment-submissions", label: "All submissions" }} eyebrow="Payment capture" title="New payment submission" description="Use details supplied by the student. The accountant remains responsible for the approval decision." actions={<ButtonLink href="/staff/payment-submissions" variant="outline">Cancel</ButtonLink>}/><PaymentSubmissionForm students={students} courses={courses}/></>;
}
