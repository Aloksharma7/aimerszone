import { Filter, Plus, WalletCards } from "lucide-react";
import { ListFilters } from "@/components/list-filters";
import { DataTable } from "@/components/portal-components";
import { ButtonLink, MetricCard, PageHeader, Panel, StatusBadge } from "@/components/ui";
import { getStaffPaymentSubmissions } from "@/lib/data/staff";
import { firstParam, matchesQuery, type PageSearchParams } from "@/lib/search-params";
import { formatNpr } from "@/lib/utils";

export default async function StaffPaymentSubmissionsPage({ searchParams }: { searchParams: PageSearchParams }) {
  const raw = await searchParams;
  const q = firstParam(raw.q);
  const status = firstParam(raw.status);
  const payments = await getStaffPaymentSubmissions();
  const filtered = payments.filter((item) => matchesQuery(q, item.id, item.student, item.course, item.method) && (!status || item.status === status));
  const pending = payments.filter((item) => !["Approved", "Rejected", "Refunded"].includes(item.status)).length;
  const returned = payments.filter((item) => item.status === "Rejected").length;

  return (
    <>
      <PageHeader eyebrow="Payment capture" title="Payment Submissions" description="Record proof received from students and submit it for accountant review." actions={<ButtonLink href="/staff/payment-submissions/new"><Plus className="h-4 w-4" />New submission</ButtonLink>} />
      <div className="grid gap-4 sm:grid-cols-3">
        <MetricCard label="Total submissions" value={String(payments.length)} icon={WalletCards} tone="amber" />
        <MetricCard label="Pending accountant" value={String(pending)} icon={Filter} tone="blue" />
        <MetricCard label="Returned / rejected" value={String(returned)} icon={Plus} tone="violet" />
      </div>
      <Panel className="mt-6">
        <ListFilters
          searchValue={q}
          searchPlaceholder="Search student, course or payment"
          resetHref="/staff/payment-submissions"
          fields={[{ name: "status", label: "Submission status", value: status, options: [{ value: "", label: "All statuses" }, { value: "Submitted", label: "Submitted" }, { value: "Under review", label: "Under review" }, { value: "Approved", label: "Approved" }, { value: "Rejected", label: "Rejected" }] }]}
        />
        <div className="mt-5"><DataTable rowKey="id" rows={filtered as unknown as Record<string, unknown>[]} columns={[{ key: "id", label: "Submission" }, { key: "student", label: "Student" }, { key: "course", label: "Course" }, { key: "amount", label: "Amount", render: (row) => <span className="font-semibold text-slate-900">{formatNpr(Number(row.amount))}</span> }, { key: "method", label: "Method" }, { key: "risk", label: "Check", render: (row) => <StatusBadge status={String(row.risk)} /> }, { key: "status", label: "Status", render: (row) => <StatusBadge status={String(row.status)} /> }]} /></div>
      </Panel>
    </>
  );
}
