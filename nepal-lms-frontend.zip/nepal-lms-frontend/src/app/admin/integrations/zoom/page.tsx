import { AlertTriangle, CheckCircle2, Video } from "lucide-react";
import { IntegrationConnection } from "@/components/admin-controls";
import { DataTable } from "@/components/portal-components";
import { MetricCard, PageHeader, Panel, StatusBadge } from "@/components/ui";
import { getAdminIntegrationRows } from "@/lib/data/admin";

export default async function ZoomIntegrationPage() {
  const rows = await getAdminIntegrationRows("zoom");
  const warnings = rows.filter((row)=>Object.values(row).some((value)=>String(value).toLowerCase().includes("warning") || String(value).toLowerCase().includes("fail"))).length;
  return <><PageHeader eyebrow="Integrations" title="Zoom meeting operations" description="Monitor connection health, session synchronization and controlled fallback readiness."/><div className="mb-6 grid gap-4 sm:grid-cols-3"><MetricCard label="Connection" value="Monitored" detail="Server-owned OAuth" icon={CheckCircle2} tone="green"/><MetricCard label="Meeting records" value={String(rows.length)} detail="Returned by Laravel" icon={Video} tone="blue"/><MetricCard label="Warnings" value={String(warnings)} detail="Require reconciliation" icon={AlertTriangle} tone="amber"/></div><IntegrationConnection provider="zoom"/><Panel className="mt-6"><h2 className="text-xl font-bold text-slate-950">Synchronization records</h2><p className="mt-1 text-sm text-slate-500">Provider state and local readiness are reviewed separately.</p><div className="mt-5"><DataTable rowKey="id" rows={rows as unknown as Record<string,unknown>[]} columns={[{key:"topic",label:"Meeting",render:(row)=><div><p className="font-semibold text-slate-900">{String(row.topic || row.title || row.id)}</p><p className="mt-1 text-xs text-slate-500">{String(row.batch || row.id)}</p></div>},{key:"scheduled",label:"Scheduled (NPT)"},{key:"host",label:"Host"},{key:"providerState",label:"Provider",render:(row)=><StatusBadge status={String(row.providerState || row.provider_state || "Unknown")}/>},{key:"localState",label:"Local readiness",render:(row)=><StatusBadge status={String(row.localState || row.local_state || "Unknown")}/>} ]}/></div></Panel></>;
}
