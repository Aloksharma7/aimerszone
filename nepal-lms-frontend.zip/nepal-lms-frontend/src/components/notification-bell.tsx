"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { Bell, Loader2 } from "lucide-react";
import { browserRequest } from "@/lib/api/browser-client";

type Notification = {
  id: string;
  title: string;
  summary: string | null;
  published_at: string | null;
  read: boolean;
  href: string | null;
};

/**
 * Notification bell with a preview panel.
 *
 * The bell was a plain link that navigated away from whatever the user was
 * doing — an unusual pattern, and it meant glancing at a notice cost you your
 * place. This shows the most recent few in place, with a link through to the
 * full page for anything longer.
 *
 * The list is fetched when the panel is first opened rather than on every page
 * load: most sessions never open it, and the unread badge does not justify a
 * request on every navigation.
 */
export function NotificationBell({ href }: { href: string }) {
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState<Notification[] | null>(null);
  const [busy, setBusy] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const unread = items?.filter((item) => !item.read).length ?? 0;

  // Close on an outside click or Escape, the behaviour a dropdown is expected
  // to have and the reason this is a panel rather than a page.
  useEffect(() => {
    if (!open) return;

    function onPointerDown(event: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setOpen(false);
      }
    }

    function onKeyDown(event: KeyboardEvent) {
      if (event.key === "Escape") setOpen(false);
    }

    document.addEventListener("mousedown", onPointerDown);
    document.addEventListener("keydown", onKeyDown);

    return () => {
      document.removeEventListener("mousedown", onPointerDown);
      document.removeEventListener("keydown", onKeyDown);
    };
  }, [open]);

  async function toggle() {
    const next = !open;
    setOpen(next);

    if (!next || items !== null) return;

    setBusy(true);

    try {
      const response = await browserRequest<{ data: Notification[] }>({
        url: "/api/v1/student/notifications",
        method: "GET",
      });

      setItems(response.data.slice(0, 6));
    } catch {
      // A failed fetch should not trap the user in an empty panel; the link
      // through to the full page still works.
      setItems([]);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div ref={containerRef} className="relative">
      <button
        type="button"
        onClick={toggle}
        aria-expanded={open}
        aria-haspopup="true"
        aria-label={unread > 0 ? `Notifications, ${unread} unread` : "Notifications"}
        className="relative flex h-10 w-10 items-center justify-center rounded-lg text-slate-600 hover:bg-slate-100"
      >
        <Bell className="h-5 w-5" />
        {unread > 0 ? (
          <span className="absolute right-1.5 top-1.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-red-600 px-1 text-[10px] font-bold text-white">
            {unread > 9 ? "9+" : unread}
          </span>
        ) : null}
      </button>

      {open ? (
        <div className="absolute right-0 z-40 mt-2 w-80 overflow-hidden rounded-xl border border-slate-200 bg-white shadow-lg">
          <div className="flex items-center justify-between border-b border-slate-100 px-4 py-3">
            <p className="text-sm font-bold text-slate-900">Notifications</p>
            <Link href={href} onClick={() => setOpen(false)} className="text-xs font-semibold text-brand-700 hover:underline">
              See all
            </Link>
          </div>

          {busy ? (
            <div className="flex items-center gap-2 px-4 py-6 text-sm text-slate-500">
              <Loader2 className="h-4 w-4 animate-spin" /> Loading…
            </div>
          ) : items && items.length > 0 ? (
            <ul className="max-h-80 divide-y divide-slate-100 overflow-y-auto">
              {items.map((item) => (
                <li key={item.id}>
                  <Link
                    href={item.href || href}
                    onClick={() => setOpen(false)}
                    className="block px-4 py-3 hover:bg-slate-50"
                  >
                    <p className={`text-sm ${item.read ? "font-medium text-slate-700" : "font-bold text-slate-900"}`}>
                      {item.title}
                    </p>
                    {item.summary ? <p className="mt-0.5 line-clamp-2 text-xs text-slate-500">{item.summary}</p> : null}
                  </Link>
                </li>
              ))}
            </ul>
          ) : (
            <p className="px-4 py-6 text-sm text-slate-500">Nothing new right now.</p>
          )}
        </div>
      ) : null}
    </div>
  );
}
