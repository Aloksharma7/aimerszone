"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import {
  AlertTriangle,
  CheckCircle2,
  CloudCog,
  LoaderCircle,
  Megaphone,
  Save,
  Send,
  ShieldCheck,
  Unplug,
} from "lucide-react";
import { AlertBox, Badge, Button, Panel, StatusBadge, fieldClass } from "@/components/ui";
import { browserRequest, createIdempotencyKey, type NormalizedApiError } from "@/lib/api/browser-client";
import { refreshPublicCatalogue } from "@/lib/catalogue-cache";
import type { ApiResponse } from "@/lib/api/contracts";
import { cn } from "@/lib/utils";
import type { AdminBatch, Course, RoleDefinition, Teacher } from "@/types/lms";
import type { AdminSettingsData } from "@/lib/data/admin";

// Shared token; see fieldClass in components/ui.
const inputClass = fieldClass;
const textareaClass = "min-h-28 w-full resize-y rounded-lg border border-slate-300 bg-white px-3 py-3 text-sm leading-6 text-slate-900 shadow-sm outline-none transition focus:border-brand-500 focus:ring-4 focus:ring-brand-100 disabled:bg-slate-100";
const mockMode = process.env.NEXT_PUBLIC_USE_MOCK_DATA === "true";

function Field({ label, required, hint, error, children }: { label: string; required?: boolean; hint?: string; error?: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-2 flex items-center gap-1 text-sm font-semibold text-slate-800">{label}{required ? <span className="text-red-600">*</span> : null}</span>
      {children}
      {hint ? <span className="mt-2 block text-xs leading-5 text-slate-500">{hint}</span> : null}
      {error ? <span className="mt-2 block text-xs font-semibold text-red-700">{error}</span> : null}
    </label>
  );
}

function Toggle({ checked, onChange, label, description }: { checked: boolean; onChange: (value: boolean) => void; label: string; description?: string }) {
  return (
    <button type="button" onClick={() => onChange(!checked)} className="flex w-full items-start justify-between gap-5 rounded-xl border border-slate-200 p-4 text-left transition hover:bg-slate-50" aria-pressed={checked}>
      <span><span className="block text-sm font-semibold text-slate-900">{label}</span>{description ? <span className="mt-1 block text-xs leading-5 text-slate-500">{description}</span> : null}</span>
      <span className={cn("relative mt-0.5 h-6 w-11 shrink-0 rounded-full transition", checked ? "bg-brand-700" : "bg-slate-300")}><span className={cn("absolute top-0.5 h-5 w-5 rounded-full bg-white shadow-sm transition", checked ? "left-[22px]" : "left-0.5")} /></span>
    </button>
  );
}

function RequestNotice({ notice }: { notice: { tone: "success" | "danger"; title: string; message: string } | null }) {
  if (!notice) return null;
  return <AlertBox title={notice.title} tone={notice.tone}>{notice.message}</AlertBox>;
}

export function BatchEditor({ mode = "new", courses, teachers, batch }: { mode?: "new" | "edit"; courses: Course[]; teachers: Teacher[]; batch?: AdminBatch | null }) {
  const router = useRouter();
  /*
   * Identifiers come from the API, not from matching display names back
   * against the option lists — a renamed course or two teachers with the same
   * name silently produced an empty selector. The date fields take the raw
   * YYYY-MM-DD values; the formatted "17 Aug 2026" strings that used to be fed
   * here are not a value <input type="date"> accepts, so the pickers always
   * rendered blank and the dates could never round-trip.
   */
  const [values, setValues] = useState({
    title: batch?.name || "",
    courseId: batch?.courseId || "",
    teacherIds: batch?.teacherIds ?? [],
    schedule: batch?.schedule && !batch.schedule.includes("required") ? batch.schedule : "",
    startDate: batch?.startAt || "",
    endDate: batch?.endAt || "",
    accessUntil: batch?.accessUntil || "",
    priceNpr: batch?.priceNpr ?? 0,
    capacity: batch?.capacity || 60,
    status: batch?.status?.toLowerCase() || "draft",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [notice, setNotice] = useState<{ tone: "success" | "danger"; title: string; message: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const editing = mode === "edit" && Boolean(batch?.id);

  function update<K extends keyof typeof values>(key: K, value: (typeof values)[K]) {
    setValues((current) => ({ ...current, [key]: value }));
    setErrors((current) => { const next = { ...current }; delete next[key]; return next; });
  }

  async function save() {
    const nextErrors: Record<string, string> = {};
    if (values.title.trim().length < 4) nextErrors.title = "Enter a clear batch title.";
    if (!values.courseId) nextErrors.courseId = "Choose a course.";
    if (!values.teacherId) nextErrors.teacherId = "Choose a teacher.";
    if (!values.schedule.trim()) nextErrors.schedule = "Enter the class schedule.";
    if (values.capacity < 1 || values.capacity > 2000) nextErrors.capacity = "Capacity must be between 1 and 2,000.";
    if (values.startDate && values.endDate && values.endDate < values.startDate) nextErrors.endDate = "End date must be after the start date.";
    if (values.accessUntil && values.endDate && values.accessUntil < values.endDate) nextErrors.accessUntil = "Access must run to at least the end date.";
    if (values.priceNpr < 0 || values.priceNpr > 10000000) nextErrors.priceNpr = "Enter a price between 0 and 10,000,000.";
    if (Object.keys(nextErrors).length) { setErrors(nextErrors); setNotice({ tone: "danger", title: "Batch not saved", message: "Please correct the highlighted fields." }); return; }
    setBusy(true); setNotice(null);
    try {
      let id = batch?.id || "preview-batch";
      if (!mockMode) {
        const response = await browserRequest<ApiResponse<{ id: string }>>({
          url: editing ? `/api/v1/admin/batches/${encodeURIComponent(batch!.id)}` : "/api/v1/admin/batches",
          method: editing ? "PATCH" : "POST",
          /*
           * Field names are the API's.
           *
           * This previously sent start_date/end_date (expected: start_at/end_at)
           * and teacher_id (expected: teacher_ids, an array). All three are
           * "sometimes" rules, so they were accepted and dropped without an
           * error: dates never saved, and no batch ever got a teacher — which
           * in turn left every teacher with an empty portal, because their
           * screens scope on the batches they are assigned to.
           *
           * enrollment_open and live_enabled had no rule and no column at all,
           * so those two toggles are gone rather than pretending to persist.
           */
          data: {
            title: values.title.trim(),
            course_id: values.courseId,
            teacher_ids: values.teacherIds,
            schedule_summary: values.schedule.trim(),
            start_at: values.startDate || null,
            end_at: values.endDate || null,
            access_until: values.accessUntil || null,
            price_npr: values.priceNpr,
            capacity: values.capacity,
            status: values.status,
          },
          headers: { "Idempotency-Key": createIdempotencyKey(editing ? "admin-update-batch" : "admin-create-batch") },
        });
        id = response.data.id;
      } else await new Promise((resolve) => window.setTimeout(resolve, 350));
      setNotice({ tone: "success", title: mockMode ? "Preview validated" : "Batch saved", message: mockMode ? "The batch payload passed client validation. Preview mode does not persist records." : "The batch and its operational settings were saved." });
      if (!editing) router.replace(`/admin/batches/${encodeURIComponent(id)}`);
      await refreshPublicCatalogue();
      router.refresh();
    } catch (caught) {
      const error = caught as Partial<NormalizedApiError>;
      setNotice({ tone: "danger", title: "Batch not saved", message: error.message || "The request could not be completed." });
    } finally { setBusy(false); }
  }

  return (
    <div className="space-y-6">
      <RequestNotice notice={notice} />
      <Panel>
        <div className="grid gap-5 sm:grid-cols-2">
          <Field label="Batch title" required error={errors.title}><input className={inputClass} value={values.title} onChange={(event) => update("title", event.target.value)} placeholder="Microeconomics · Evening Batch 2083" /></Field>
          <Field label="Course" required error={errors.courseId}><select className={inputClass} value={values.courseId} onChange={(event) => update("courseId", event.target.value)}><option value="">Select course</option>{courses.map((course) => <option key={course.id || course.slug} value={course.id || course.slug}>{course.title}</option>)}</select></Field>
          {/*
            * More than one teacher per batch.
            *
            * The API has always taken a list and the pivot has always held
            * many, but the form sent a single id — so a batch shared between a
            * theory and a practical teacher could not be described, and there
            * was no way to see who was already assigned, or to change them
            * without guessing.
            */}
          <Field label="Teachers" required error={errors.teacherIds} hint="Tick everyone who teaches this batch. They each see it in their own portal.">
            <div className="mt-2 max-h-56 space-y-1 overflow-y-auto rounded-lg border border-slate-300 p-2">
              {teachers.length ? teachers.map((teacher) => {
                const id = teacher.userId || "";
                const checked = values.teacherIds.includes(id);
                return (
                  <label key={id || teacher.slug} className="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-2 hover:bg-slate-50">
                    <input
                      type="checkbox"
                      className="h-4 w-4 accent-brand-700"
                      checked={checked}
                      disabled={!id}
                      onChange={() => update("teacherIds", checked ? values.teacherIds.filter((item) => item !== id) : [...values.teacherIds, id])}
                    />
                    <span className="text-sm text-slate-800">{teacher.name}</span>
                    {checked ? <span className="ml-auto text-xs font-semibold text-green-700">Assigned</span> : null}
                  </label>
                );
              }) : <p className="px-2 py-3 text-sm text-slate-500">No teacher accounts yet. Create one under Users first.</p>}
            </div>
          </Field>
          <Field label="Capacity" required error={errors.capacity}><input className={inputClass} type="number" min="1" max="2000" value={values.capacity} onChange={(event) => update("capacity", Number(event.target.value) || 0)} /></Field>
          <Field label="Start date"><input className={inputClass} type="date" value={values.startDate} onChange={(event) => update("startDate", event.target.value)} /></Field>
          <Field label="End date" error={errors.endDate}><input className={inputClass} type="date" value={values.endDate} onChange={(event) => update("endDate", event.target.value)} /></Field>
          <Field label="Access until" error={errors.accessUntil} hint="Content stays available to enrolled students until this date. Leave blank to use the institution default."><input className={inputClass} type="date" value={values.accessUntil} onChange={(event) => update("accessUntil", event.target.value)} /></Field>
          <Field label="Price (NPR)" error={errors.priceNpr} hint="The fee students are asked for. 0 makes the batch free."><input className={inputClass} type="number" min="0" max="10000000" value={values.priceNpr} onChange={(event) => update("priceNpr", Number(event.target.value) || 0)} /></Field>
          <div className="sm:col-span-2"><Field label="Schedule summary" required error={errors.schedule} hint="Use Nepal time and keep the public schedule concise."><input className={inputClass} value={values.schedule} onChange={(event) => update("schedule", event.target.value)} placeholder="Sun–Fri · 7:00–8:00 PM NPT" /></Field></div>
          <Field label="Operational status"><select className={inputClass} value={values.status} onChange={(event) => update("status", event.target.value)}><option value="draft">Draft</option><option value="open">Open</option><option value="ongoing">Ongoing</option><option value="closed">Closed</option><option value="cancelled">Cancelled</option></select></Field>
        </div>
        {/*
          * "Enrollment open" and "Live classes enabled" used to sit here as
          * toggles. Neither had a column or a validation rule behind it, so
          * both were discarded on every save while appearing to work.
          * Enrollment is governed by the operational status above.
          */}
        <p className="mt-6 rounded-xl bg-slate-50 px-4 py-3 text-sm leading-6 text-slate-600">
          Enrollment follows the operational status: a batch accepts new students while it is <strong>Open</strong>. Capacity, dates, payment and eligibility are all re-checked by the API on every enrolment.
        </p>
        <div className="mt-6 flex justify-end"><Button onClick={save} disabled={busy}>{busy ? <LoaderCircle className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}{busy ? "Saving…" : editing ? "Save batch" : "Create batch"}</Button></div>
      </Panel>
    </div>
  );
}

export function RoleMatrix({ roles }: { roles: RoleDefinition[] }) {
  const permissions = useMemo(() => [...new Set(roles.flatMap((role) => role.permissions))].sort(), [roles]);
  return (
    <Panel>
      <div className="flex items-start justify-between gap-4"><div><h2 className="text-xl font-bold text-slate-950">Protected role matrix</h2><p className="mt-1 text-sm leading-6 text-slate-500">This page is an operational view. Laravel policies and permission seeding remain the source of truth.</p></div><ShieldCheck className="h-6 w-6 text-brand-700" /></div>
      <div className="mt-6 overflow-x-auto"><table className="min-w-full border-separate border-spacing-0 text-sm"><thead><tr><th className="sticky left-0 z-10 border-b border-slate-200 bg-white px-4 py-3 text-left font-bold text-slate-700">Permission</th>{roles.map((role) => <th key={role.id} className="border-b border-slate-200 px-4 py-3 text-center font-bold text-slate-700"><span className="block whitespace-nowrap">{role.name}</span><span className="mt-1 block text-xs font-normal text-slate-400">{role.users} users</span></th>)}</tr></thead><tbody>{permissions.map((permission) => <tr key={permission}><td className="sticky left-0 border-b border-slate-100 bg-white px-4 py-3 font-medium text-slate-700">{permission}</td>{roles.map((role) => <td key={`${role.id}-${permission}`} className="border-b border-slate-100 px-4 py-3 text-center">{role.permissions.includes(permission) ? <CheckCircle2 className="mx-auto h-5 w-5 text-green-600" /> : <span className="text-slate-300">—</span>}</td>)}</tr>)}</tbody></table></div>
      <div className="mt-5 flex gap-3 rounded-xl border border-blue-200 bg-blue-50 p-4 text-sm leading-6 text-blue-900"><ShieldCheck className="mt-0.5 h-5 w-5 shrink-0" /><p>Permission changes should be reviewed, migrated, tested and audited on the backend—not toggled casually in a browser table.</p></div>
    </Panel>
  );
}

export function AnnouncementComposer({ batches, roles }: { batches: AdminBatch[]; roles: RoleDefinition[] }) {
  const [values, setValues] = useState({ title: "", body: "", audience: "all", targetId: "", channel: "in_app", schedule: "" });
  const [notice, setNotice] = useState<{ tone: "success" | "danger"; title: string; message: string } | null>(null);
  const [busy, setBusy] = useState(false);
  async function submit(status: "draft" | "published") {
    if (values.title.trim().length < 4 || values.body.trim().length < 10) { setNotice({ tone: "danger", title: "Announcement not saved", message: "Add a clear title and message." }); return; }
    setBusy(true); setNotice(null);
    try {
      if (!mockMode) await browserRequest<ApiResponse<{ id: string }>>({ url: "/api/v1/admin/announcements", method: "POST", data: { title: values.title.trim(), body: values.body.trim(), audience_type: values.audience, audience_id: values.targetId || null, channel: values.channel, scheduled_at: values.schedule || null, status }, headers: { "Idempotency-Key": createIdempotencyKey(`admin-announcement-${status}`) } });
      else await new Promise((resolve) => window.setTimeout(resolve, 300));
      setNotice({ tone: "success", title: mockMode ? "Preview validated" : status === "published" ? "Announcement published" : "Draft saved", message: mockMode ? "The announcement payload is ready for Laravel." : "The audience and delivery request were recorded." });
      if (status === "published") setValues({ title: "", body: "", audience: "all", targetId: "", channel: "in_app", schedule: "" });
    } catch (caught) { const error = caught as Partial<NormalizedApiError>; setNotice({ tone: "danger", title: "Announcement not saved", message: error.message || "The request could not be completed." }); }
    finally { setBusy(false); }
  }
  const targets = values.audience === "batch" ? batches.map((batch) => ({ id: batch.id, label: batch.name })) : values.audience === "role" ? roles.map((role) => ({ id: role.id, label: role.name })) : [];
  return (
    <div className="space-y-4"><RequestNotice notice={notice} /><Panel><div className="flex items-start justify-between gap-4"><div><h2 className="text-xl font-bold text-slate-950">Create announcement</h2><p className="mt-1 text-sm leading-6 text-slate-500">Target a role or batch. Private meeting and file links must never be pasted into the message.</p></div><Megaphone className="h-6 w-6 text-brand-700" /></div><div className="mt-6 grid gap-5 sm:grid-cols-2"><div className="sm:col-span-2"><Field label="Title" required><input className={inputClass} value={values.title} maxLength={120} onChange={(event) => setValues((current) => ({ ...current, title: event.target.value }))} /></Field></div><Field label="Audience"><select className={inputClass} value={values.audience} onChange={(event) => setValues((current) => ({ ...current, audience: event.target.value, targetId: "" }))}><option value="all">All active users</option><option value="role">One role</option><option value="batch">One batch</option></select></Field><Field label="Audience target"><select className={inputClass} value={values.targetId} onChange={(event) => setValues((current) => ({ ...current, targetId: event.target.value }))} disabled={!targets.length}><option value="">{targets.length ? "Select target" : "Not required"}</option>{targets.map((item) => <option key={item.id} value={item.id}>{item.label}</option>)}</select></Field><Field label="Channel"><select className={inputClass} value={values.channel} onChange={(event) => setValues((current) => ({ ...current, channel: event.target.value }))}><option value="in_app">In-app</option><option value="in_app_email">In-app and email</option></select></Field><Field label="Schedule (optional)"><input className={inputClass} type="datetime-local" value={values.schedule} onChange={(event) => setValues((current) => ({ ...current, schedule: event.target.value }))} /></Field><div className="sm:col-span-2"><Field label="Message" required><textarea className={textareaClass} value={values.body} maxLength={5000} onChange={(event) => setValues((current) => ({ ...current, body: event.target.value }))} /></Field></div></div><div className="mt-6 flex flex-wrap justify-end gap-2"><Button variant="outline" onClick={() => submit("draft")} disabled={busy}><Save className="h-4 w-4" />Save draft</Button><Button onClick={() => submit("published")} disabled={busy}>{busy ? <LoaderCircle className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}Publish / schedule</Button></div></Panel></div>
  );
}

export function SettingsManager({ initialData }: { initialData: AdminSettingsData }) {
  const [values, setValues] = useState(initialData);
  const [notice, setNotice] = useState<{ tone: "success" | "danger"; title: string; message: string } | null>(null);
  const [busy, setBusy] = useState(false);
  async function save() {
    setBusy(true); setNotice(null);
    try {
      if (!mockMode) await browserRequest<ApiResponse<AdminSettingsData>>({ url: "/api/v1/admin/settings", method: "PATCH", data: { institution: { name: values.institution.name, short_name: values.institution.shortName, primary_phone: values.institution.primaryPhone, support_email: values.institution.supportEmail, whatsapp: values.institution.whatsapp, website: values.institution.website, address: values.institution.address }, payment_methods: values.paymentMethods.map((item) => ({ id: item.id, name: item.name, account_name: item.accountName, account_reference: item.accountReference, status: item.status.toLowerCase(), sort_order: item.sort })), security: { public_registration: values.security.publicRegistration, email_verification: values.security.emailVerification, privileged_mfa: values.security.privilegedMfa, force_password_change: values.security.forcePasswordChange, session_timeout_hours: values.security.sessionTimeoutHours, failed_login_attempts: values.security.failedLoginAttempts, lockout_minutes: values.security.lockoutMinutes }, operations: { maintenance_notice: values.operations.maintenanceNotice, automatic_receipts: values.operations.automaticReceipts, daily_integration_health_check: values.operations.dailyIntegrationHealthCheck } }, headers: { "Idempotency-Key": createIdempotencyKey("admin-settings") } });
      else await new Promise((resolve) => window.setTimeout(resolve, 350));
      setNotice({ tone: "success", title: mockMode ? "Preview validated" : "Settings saved", message: mockMode ? "The settings payload is ready for the Laravel settings endpoint." : "Configuration was saved and the change should appear in the audit log." });
    } catch (caught) { const error = caught as Partial<NormalizedApiError>; setNotice({ tone: "danger", title: "Settings not saved", message: error.message || "The request could not be completed." }); }
    finally { setBusy(false); }
  }
  return (
    <div className="space-y-6"><RequestNotice notice={notice} /><Panel><h2 className="text-xl font-bold text-slate-950">Institution identity</h2><div className="mt-5 grid gap-5 sm:grid-cols-2"><Field label="Institution name"><input className={inputClass} value={values.institution.name} onChange={(event) => setValues((current) => ({ ...current, institution: { ...current.institution, name: event.target.value } }))} /></Field><Field label="Short name"><input className={inputClass} value={values.institution.shortName} onChange={(event) => setValues((current) => ({ ...current, institution: { ...current.institution, shortName: event.target.value } }))} /></Field><Field label="Support email"><input className={inputClass} type="email" value={values.institution.supportEmail} onChange={(event) => setValues((current) => ({ ...current, institution: { ...current.institution, supportEmail: event.target.value } }))} /></Field><Field label="Primary phone"><input className={inputClass} value={values.institution.primaryPhone} onChange={(event) => setValues((current) => ({ ...current, institution: { ...current.institution, primaryPhone: event.target.value } }))} /></Field><Field label="WhatsApp"><input className={inputClass} value={values.institution.whatsapp} onChange={(event) => setValues((current) => ({ ...current, institution: { ...current.institution, whatsapp: event.target.value } }))} /></Field><Field label="Public website"><input className={inputClass} type="url" value={values.institution.website} onChange={(event) => setValues((current) => ({ ...current, institution: { ...current.institution, website: event.target.value } }))} /></Field><div className="sm:col-span-2"><Field label="Address"><textarea className={textareaClass} value={values.institution.address} onChange={(event) => setValues((current) => ({ ...current, institution: { ...current.institution, address: event.target.value } }))} /></Field></div></div></Panel><Panel><h2 className="text-xl font-bold text-slate-950">Security defaults</h2><div className="mt-5 grid gap-4 sm:grid-cols-2"><Toggle checked={values.security.publicRegistration} onChange={(value) => setValues((current) => ({ ...current, security: { ...current.security, publicRegistration: value } }))} label="Public registration" /><Toggle checked={values.security.emailVerification} onChange={(value) => setValues((current) => ({ ...current, security: { ...current.security, emailVerification: value } }))} label="Require email verification" /><Toggle checked={values.security.privilegedMfa} onChange={(value) => setValues((current) => ({ ...current, security: { ...current.security, privilegedMfa: value } }))} label="Require MFA for privileged roles" /><Toggle checked={values.security.forcePasswordChange} onChange={(value) => setValues((current) => ({ ...current, security: { ...current.security, forcePasswordChange: value } }))} label="Force temporary-password change" /></div><div className="mt-5 grid gap-5 sm:grid-cols-3"><Field label="Session timeout (hours)"><input className={inputClass} type="number" min="1" max="24" value={values.security.sessionTimeoutHours} onChange={(event) => setValues((current) => ({ ...current, security: { ...current.security, sessionTimeoutHours: Number(event.target.value) || 1 } }))} /></Field><Field label="Failed attempts"><input className={inputClass} type="number" min="3" max="20" value={values.security.failedLoginAttempts} onChange={(event) => setValues((current) => ({ ...current, security: { ...current.security, failedLoginAttempts: Number(event.target.value) || 3 } }))} /></Field><Field label="Lockout minutes"><input className={inputClass} type="number" min="5" max="1440" value={values.security.lockoutMinutes} onChange={(event) => setValues((current) => ({ ...current, security: { ...current.security, lockoutMinutes: Number(event.target.value) || 5 } }))} /></Field></div></Panel><Panel><h2 className="text-xl font-bold text-slate-950">Operational controls</h2><div className="mt-5 grid gap-4 sm:grid-cols-3"><Toggle checked={values.operations.maintenanceNotice} onChange={(value) => setValues((current) => ({ ...current, operations: { ...current.operations, maintenanceNotice: value } }))} label="Maintenance notice" /><Toggle checked={values.operations.automaticReceipts} onChange={(value) => setValues((current) => ({ ...current, operations: { ...current.operations, automaticReceipts: value } }))} label="Automatic receipts" /><Toggle checked={values.operations.dailyIntegrationHealthCheck} onChange={(value) => setValues((current) => ({ ...current, operations: { ...current.operations, dailyIntegrationHealthCheck: value } }))} label="Daily integration check" /></div><div className="mt-6 flex justify-end"><Button onClick={save} disabled={busy}>{busy ? <LoaderCircle className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}{busy ? "Saving…" : "Save settings"}</Button></div></Panel></div>
  );
}

export function IntegrationConnection({ provider }: { provider: "zoom" | "youtube" }) {
  const label = provider === "zoom" ? "Zoom" : "YouTube";
  const [connected, setConnected] = useState(true);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<{ tone: "success" | "danger"; title: string; message: string } | null>(null);
  async function action(name: "connect" | "disconnect" | "health-check") {
    if (name === "disconnect" && !window.confirm(`Disconnect ${label}? Existing local records will remain but provider actions may stop.`)) return;
    setBusy(true); setNotice(null);
    try {
      if (!mockMode) await browserRequest<ApiResponse<{ connected: boolean; status: string }>>({ url: `/api/v1/admin/integrations/${provider}/${name}`, method: "POST", headers: { "Idempotency-Key": createIdempotencyKey(`admin-${provider}-${name}`) } });
      else await new Promise((resolve) => window.setTimeout(resolve, 300));
      if (name === "connect") setConnected(true); if (name === "disconnect") setConnected(false);
      setNotice({ tone: "success", title: `${label} request completed`, message: mockMode ? "Preview mode validated the provider action." : name === "health-check" ? "The health check result was recorded." : `${label} connection state was updated.` });
    } catch (caught) { const error = caught as Partial<NormalizedApiError>; setNotice({ tone: "danger", title: `${label} request failed`, message: error.message || "The request could not be completed." }); }
    finally { setBusy(false); }
  }
  return (
    <div className="space-y-4"><RequestNotice notice={notice} /><Panel><div className="flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between"><div className="flex items-start gap-4"><div className={cn("flex h-12 w-12 items-center justify-center rounded-xl", connected ? "bg-green-50 text-green-700" : "bg-slate-100 text-slate-500")}><CloudCog className="h-6 w-6" /></div><div><div className="flex flex-wrap items-center gap-2"><h2 className="text-xl font-bold text-slate-950">{label} connection</h2><StatusBadge status={connected ? "Active" : "Disconnected"} /></div><p className="mt-1 max-w-2xl text-sm leading-6 text-slate-500">OAuth credentials and provider secrets stay on Laravel. The browser only requests connection and health actions.</p></div></div><div className="flex flex-wrap gap-2"><Button variant="outline" onClick={() => action("health-check")} disabled={busy}><ShieldCheck className="h-4 w-4" />Health check</Button>{connected ? <Button variant="danger" onClick={() => action("disconnect")} disabled={busy}><Unplug className="h-4 w-4" />Disconnect</Button> : <Button onClick={() => action("connect")} disabled={busy}><CloudCog className="h-4 w-4" />Connect</Button>}</div></div><div className="mt-5 flex gap-3 rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm leading-6 text-amber-900"><AlertTriangle className="mt-0.5 h-5 w-5 shrink-0" /><p>Provider links, access tokens and webhook secrets must never be returned in page data or embedded in the frontend bundle.</p></div></Panel></div>
  );
}
