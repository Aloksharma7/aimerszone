"use client";

import { useEffect } from "react";

/**
 * Forces a reload when a portal page is restored from the browser's
 * back-forward cache.
 *
 * `Cache-Control: no-store` is already set on protected routes, and Chrome
 * honours it by skipping bfcache — but Safari and Firefox still restore a
 * fully rendered page from memory. After signing out, pressing Back therefore
 * showed the previous user's dashboard, complete with their name and data. On a
 * shared computer at an institution that is exactly the wrong outcome.
 *
 * `event.persisted` is true only for a bfcache restore, so a normal navigation
 * is untouched. The reload re-runs the server component, which has no session
 * and redirects to /login.
 */
export function SessionIntegrity() {
  useEffect(() => {
    function handlePageShow(event: PageTransitionEvent) {
      if (event.persisted) {
        window.location.reload();
      }
    }

    window.addEventListener("pageshow", handlePageShow);
    return () => window.removeEventListener("pageshow", handlePageShow);
  }, []);

  return null;
}
