"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowDownUp, LoaderCircle, Save } from "lucide-react";
import { AlertBox, Button, Panel, labelledFieldClass } from "@/components/ui";
import { browserRequest, createIdempotencyKey, normalizeApiError } from "@/lib/api/browser-client";
import type { ApiResponse } from "@/lib/api/contracts";

const mockMode = process.env.NEXT_PUBLIC_USE_MOCK_DATA === "true";
// Shared token; see fieldClass in components/ui.
const inputClass = labelledFieldClass;

export function AccountingAdjustmentForm() {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<{ tone: "success" | "danger"; title: string; message: string } | null>(null);

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (busy) return;
    const form = new FormData(event.currentTarget);
    const data = {
      payment_id: String(form.get("payment_id") || "").trim(),
      type: String(form.get("type") || "credit"),
      amount_npr: Number(form.get("amount_npr") || 0),
      reason: String(form.get("reason") || "").trim(),
      authorization_reference: String(form.get("authorization_reference") || "").trim(),
    };
    if (data.payment_id.length < 3 || !Number.isFinite(data.amount_npr) || data.amount_npr <= 0 || data.reason.length < 10 || data.authorization_reference.length < 3) {
      setNotice({ tone: "danger", title: "Adjustment not submitted", message: "Enter a payment ID, positive amount, authorization reference and a clear reason." });
      return;
    }
    setBusy(true); setNotice(null);
    try {
      if (mockMode) {
        setNotice({ tone: "success", title: "Preview validated", message: "Laravel will verify the payment, authorization, policy limits and duplicate requests before creating the adjustment." });
        return;
      }
      const response = await browserRequest<ApiResponse<{ id: string }>>({
        url: "/api/v1/accounting/adjustments",
        method: "POST",
        data,
        headers: { "Idempotency-Key": createIdempotencyKey("accounting-adjustment") },
      });
      router.replace(`/accounting/adjustments?created=${encodeURIComponent(response.data.id)}`);
      router.refresh();
    } catch (caught) {
      setNotice({ tone: "danger", title: "Adjustment not submitted", message: normalizeApiError(caught).message });
    } finally { setBusy(false); }
  }

  return <div className="grid gap-6 xl:grid-cols-[1fr_340px]"><Panel><div className="flex items-center gap-3"><ArrowDownUp className="h-6 w-6 text-brand-700" /><h2 className="text-xl font-bold text-slate-950">Adjustment details</h2></div>{notice ? <div className="mt-5"><AlertBox title={notice.title} tone={notice.tone}>{notice.message}</AlertBox></div> : null}<form onSubmit={submit} className="mt-6 grid gap-5 sm:grid-cols-2" noValidate><label className="text-sm font-semibold text-slate-700 sm:col-span-2">Authoritative payment ID<input name="payment_id" required maxLength={100} className={inputClass} placeholder="PAY-…" /></label><label className="text-sm font-semibold text-slate-700">Adjustment type<select name="type" className={inputClass}><option value="credit">Credit</option><option value="debit">Debit</option><option value="reversal">Reversal</option><option value="refund">Refund</option></select></label><label className="text-sm font-semibold text-slate-700">Amount (NPR)<input name="amount_npr" type="number" min="1" step="1" required className={inputClass} /></label><label className="text-sm font-semibold text-slate-700 sm:col-span-2">Authorization reference<input name="authorization_reference" required maxLength={120} className={inputClass} placeholder="Approval ticket, policy reference or manager authorization" /></label><label className="text-sm font-semibold text-slate-700 sm:col-span-2">Permanent reason<textarea name="reason" required minLength={10} maxLength={1000} className="mt-2 min-h-28 w-full rounded-lg border border-slate-300 p-3 font-normal outline-none focus:border-brand-600 focus:ring-2 focus:ring-brand-100" /></label><div className="sm:col-span-2"><Button type="submit" disabled={busy}>{busy ? <LoaderCircle className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}{busy ? "Submitting…" : "Submit adjustment"}</Button></div></form></Panel><aside className="space-y-5"><AlertBox title="No destructive edits" tone="warning">Laravel creates a separate immutable financial action. It never overwrites or deletes the original payment and receipt.</AlertBox><AlertBox title="Server authorization required" tone="info">The backend rechecks accountant permission, amount limits, approval policy, payment state and idempotency before committing anything.</AlertBox></aside></div>;
}
