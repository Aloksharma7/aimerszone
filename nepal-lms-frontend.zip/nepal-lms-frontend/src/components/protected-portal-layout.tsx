import { PortalShell } from "@/components/portal-shell";
import { SessionIntegrity } from "@/components/auth/session-integrity";
import { SessionProvider } from "@/components/auth/session-provider";
import { requirePortalAccess } from "@/lib/auth/server";
import { isMockDataEnabled } from "@/lib/data/config";
import type { PortalRole } from "@/types/lms";

export async function ProtectedPortalLayout({
  role,
  children,
}: {
  role: PortalRole;
  children: React.ReactNode;
}) {
  const user = await requirePortalAccess(role);

  /*
   * The chrome follows the person, not the URL.
   *
   * Administrators can reach teacher and staff screens, and the sidebar used to
   * swap to that portal's menu underneath them — so opening "Classes" from the
   * admin menu replaced the whole admin navigation with the teacher one and
   * left no way back except the browser button. An administrator keeps the
   * administrator menu wherever they are; everyone else only ever sees their
   * own portal anyway.
   */
  const chrome: PortalRole = user.roles.includes("admin") ? "admin" : role;

  return (
    <SessionProvider user={user}>
      {/* Back-button after sign-out must not reveal the previous session. */}
      <SessionIntegrity />
      <PortalShell role={chrome} user={user} mockMode={isMockDataEnabled()}>
        {children}
      </PortalShell>
    </SessionProvider>
  );
}
