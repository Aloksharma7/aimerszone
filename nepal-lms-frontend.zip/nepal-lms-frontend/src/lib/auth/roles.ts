import type { MachineRole, PortalRole, SessionUser } from "@/types/lms";

export const portalRoleToMachineRole: Record<PortalRole, MachineRole> = {
  student: "student",
  teacher: "teacher",
  staff: "enrollment_officer",
  accounting: "accountant",
  admin: "admin",
};

export const portalHomeByMachineRole: Record<MachineRole, string> = {
  student: "/student/dashboard",
  teacher: "/teacher/dashboard",
  enrollment_officer: "/staff/dashboard",
  accountant: "/accounting/dashboard",
  admin: "/admin/dashboard",
};

/**
 * Administrators reach every portal.
 *
 * `can()` already treats admin as a superuser, and the Laravel `EnsureRole`
 * middleware lets admin through any role gate. Without the same rule here the
 * frontend disagreed with the backend: an admin opening /staff/students was
 * bounced back to /admin/dashboard even though the API would have served them.
 */
export function hasRole(user: SessionUser, role: PortalRole): boolean {
  if (user.roles.includes("admin")) return true;
  return user.roles.includes(portalRoleToMachineRole[role]);
}

export function can(user: SessionUser, permission: string): boolean {
  return user.roles.includes("admin") || user.permissions.includes(permission);
}

export function preferredPortalHome(user: Pick<SessionUser, "portalHome" | "roles">): string {
  // An admin visiting another portal is allowed to stay there; this is only
  // the landing page used after sign-in or when a route is genuinely denied.
  if (user.portalHome?.startsWith("/")) return user.portalHome;
  const priority: MachineRole[] = ["admin", "accountant", "enrollment_officer", "teacher", "student"];
  const role = priority.find((candidate) => user.roles.includes(candidate));
  return role ? portalHomeByMachineRole[role] : "/unauthorized";
}
