import { describe, expect, it } from "vitest";
import { can, hasRole, preferredPortalHome } from "@/lib/auth/roles";
import type { SessionUser } from "@/types/lms";

const user: SessionUser = {
  id: "u1",
  name: "Test User",
  email: null,
  mobile: null,
  studentCode: null,
  avatarUrl: null,
  status: "active",
  roles: ["enrollment_officer"],
  permissions: ["courses.view", "courses.create"],
  requiredAction: null,
  portalHome: "/staff/dashboard",
};

describe("role helpers", () => {
  it("maps the staff portal to enrollment_officer", () => {
    expect(hasRole(user, "staff")).toBe(true);
    expect(hasRole(user, "admin")).toBe(false);
  });

  it("checks explicit permissions and preserves a safe portal home", () => {
    expect(can(user, "courses.create")).toBe(true);
    expect(can(user, "payments.review")).toBe(false);
    expect(preferredPortalHome(user)).toBe("/staff/dashboard");
  });
});
